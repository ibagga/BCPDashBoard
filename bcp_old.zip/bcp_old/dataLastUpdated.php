
<?php

$dir = "C://Users//Public//eclipse-workspace//MasterDataShare//Driver//Logs";
$files = scan_dir($dir);

foreach($files as $key => $value)
{
	$path = realpath($dir.DIRECTORY_SEPARATOR.$value);
	
	if(is_dir($path)) 
	{
		continue;
	} 
	else  
	{
		$handle = fopen($path, "r") or die("Couldn't get handle");
		if ($handle) {
			while (!feof($handle)) {
				
				$buffer = fgets($handle, 4096);
				if( strpos($buffer, "Success import excel to mysql table") !== false) 
				{
					$fileName = pathinfo($path);
					$pieces = explode(" ", $fileName['filename']);
					$date = date_create($pieces[0]);
					$date = date_format($date,"d M Y");					
					//echo $date;
					
					$time = str_replace("-",":",$pieces[1]);
					//echo $time;
					
					$lastUpdated = $date." ".$time;
					echo "Data as on - " . $lastUpdated;
					break 2;
				}
			}
			fclose($handle);
		}	
	}
}

//Function to scan files in date modified order
function scan_dir($dir) {
    $ignored = array('.', '..');

    $files = array();    
    foreach (scandir($dir) as $file) {
        if (in_array($file, $ignored)) continue;
        $files[$file] = filemtime($dir . '/' . $file);
    }

    arsort($files);
    $files = array_keys($files);

    return ($files) ? $files : false;
}

?>