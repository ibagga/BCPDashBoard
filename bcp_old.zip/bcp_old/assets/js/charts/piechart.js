var k = 0;
var teamfte = 0
var currentRequest1 = null;

// Radialize the colors
Highcharts.getOptions().colors = Highcharts.map(Highcharts.getOptions().colors, function(color) {
    return {
        radialGradient: {
            cx: 0.5,
            cy: 0.3,
            r: 0.7
        },
        stops: [
            [0, color],
            [1, Highcharts.Color(color).brighten(-0.2).get('rgb')] // darken
        ]
    };
});


function piedefect(ids, role, start_Date, end_Date, ftecount) {
    var categoryDefect = [];
    ///////////////	   alert(end_Date);
    var options = {
        chart: {
            renderTo: 'container3',
            plotBackgroundColor: null,
            plotBorderWidth: true,
            plotShadow: false,
            type: 'pie',


            margin: 30,
            showInLegend: true
        },
        legend: {
            itemStyle: {

                fontWeight: 'normal',
                fontSize: '11px'
            }
        },
        credits: {
            enabled: false
        },
        title: {
            text: '',
            fontSize: '9px',
            fontWeight: 'bold',
        },
        subtitle: {
            text: 'Defect Categorization',
            fontSize: '9px',
            fontWeight: 'bold',
            y: 380
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y:.0f}, {point.percentage:.1f} %</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y:.0f}, {point.percentage:.1f} %',
                    style: {
                        fontWeight: 'normal',
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    },
                    connectorColor: 'silver'
                }
            }
        },
        series: [{
            type: 'pie',
            name: 'Defect share',
            data: []
        }]

    }

    if (role == 0) {
        var quotedIds = [];
        for (var i = 0; i < ids.length; ++i)
            quotedIds.push("'" + ids[i] + "'");
        quotedIds = quotedIds.join(", ");
        //alert(quotedIds);
        $.getJSON('/assets/php/User/piedefectteamuser.php', {
                ids: quotedIds,
                start_Date: start_Date,
                end_Date: end_Date
            },
            function(json) {
                options.series[0].data = json;
                chart = new Highcharts.Chart(options);
            });
    } else {
        var quotedIds = [];
        for (var i = 0; i < ids.length; ++i)
            quotedIds.push(ids[i]);
        quotedIds = quotedIds.join(", ");
        quotedIds = quotedIds.replace(/,\s*$/, "");

        currentRequest1 = $.ajax({
            url: "/assets/php/Head/piedefectheadteam.php",
            type: "GET",
            dataType: 'json',
            data: {
                ids: quotedIds,
                start_Date: start_Date,
                end_Date: end_Date
            },
            beforeSend: function() {
                if (currentRequest1 != null) {
                    //alert("test");
                    currentRequest1.abort();
                }
            },
            complete: function() {
                currentRequest1 = null;
				
				$('.loader').hide();
            },
            success: function(json) {
                //alert("test");
				ndApriltoJan = json[8][1];
				tdApriltoJan = json[9][1];
				//delete json[8];
				//delete json[9];
				console.log("test"+ndApriltoJan+ " " +tdApriltoJan);
				json[8][1]='';
				json[9][1]='';
                categoryDefect[0] = json[0][1] + json[1][1] + json[2][1] + json[3][1] + json[4][1] + json[5][1] + json[6][1] + json[7][1];
                categoryDefect[1] = json[3][1];
                categoryDefect[2] = json[1][1];
                totalincident = categoryDefect[0];
                newDefect = categoryDefect[1];
				console.log("newDefect1 "+newDefect);
                devRequest = categoryDefect[2];
                $("#totalincident").text(totalincident);
				//alert(ids.length);
                if (ids.length == '10') {
                    if ($("#checkbox").is(':checked'))
                        $('#select2-chosen-1').text("All Selected");
                    else
                        $('#select2-chosen-1').text("Select a Team");
                    teamfte = (newDefect / ftecount).toFixed(2);
                }
				//alert(teamfte);
                $("#hdvrnumberper").text(teamfte);
                //k++;
                ////alert(k);
                $("#ndvr").text(newDefect);
                $("#devrequest").text(devRequest);
				console.log(ndApriltoJan);
				console.log(tdApriltoJan);
                //$("#ndvrnumberper").text((((newDefect-ndApriltoJan)  / (totalincident - tdApriltoJan - devRequest)) * 100).toFixed(2) + "%");
                $("#ndvrnumberper").text((((newDefect-ndApriltoJan)  / (totalincident - tdApriltoJan - devRequest)) * 100).toFixed(2) + "%");
                $("#hdvr").text((newDefect / ftecount).toFixed(2));

                $.each(json, function(key, value) {
					//console.log(json[key]);
                    //alert(json[key][1]);
                    if (value === "" || value === null || json[key][1] == "0" || json[key][1] == 0 || json['ndjtoa'] || json['tdjtoa']) {
						//console.log(json[key]);
                        delete json[key];
                        //alert(json[key]);
                    }
                });
                json = json.filter(function(x) {
                    return x !== null
                });
                //alert(json);
                options.series[0].data = json;
                chart = new Highcharts.Chart(options);
                //alert(json[1][1]);
                //alert(categoryDefect[2]);		
            }
        });
    }

    return categoryDefect;

}


function piedefectteam(loggeduser, ids, role, start_Date, end_Date, ftecount) {
    var categoryDefect = [];
    ///////////////	   alert(end_Date);
    var options = {
        chart: {
            renderTo: 'container3',
            plotBackgroundColor: null,
            plotBorderWidth: true,
            plotShadow: false,
            type: 'pie',


            margin: 30,
            showInLegend: true
        },
        legend: {
            itemStyle: {

                fontWeight: 'normal',
                fontSize: '11px'
            }
        },
        credits: {
            enabled: false
        },
        title: {
            text: '',
            fontSize: '9px',
            fontWeight: 'bold',
        },
        subtitle: {
            text: 'Defect Categorization',
            fontSize: '9px',
            fontWeight: 'bold',
            y: 380
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y:.0f}, {point.percentage:.1f} %</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y:.0f}, {point.percentage:.1f} %',
                    style: {
                        fontWeight: 'normal',
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    },
                    connectorColor: 'silver'
                }
            }
        },
        series: [{
            type: 'pie',
            name: 'Defect share',
            data: []
        }]

    }

    if (role == 0) {
        var quotedIds = [];
        for (var i = 0; i < ids.length; ++i)
            quotedIds.push("'" + ids[i] + "'");
        quotedIds = quotedIds.join(", ");
        //alert(quotedIds);
        $.getJSON('/assets/php/Manager/piedefectteamman.php', {
                loggeduser: loggeduser,
                ids: quotedIds,
                start_Date: start_Date,
                end_Date: end_Date
            },
            function(json) {
				//alert("test");
				ndApriltoJan = json[8][1];
				tdApriltoJan = json[9][1];
				//delete json[8];
				//delete json[9];
				json[8][1]='';
				json[9][1]='';
				console.log("test"+ndApriltoJan+" "+tdApriltoJan);
                //alert(ids);
                categoryDefect[0] = json[0][1] + json[1][1] + json[2][1] + json[3][1] + json[4][1] + json[5][1] + json[6][1] + json[7][1];
                categoryDefect[1] = json[3][1];
                categoryDefect[2] = json[1][1];
                totalincident = categoryDefect[0];
                newDefect = categoryDefect[1];
                devRequest = categoryDefect[2];
                highDefect = $('#hdvr').text();
                teamfte = (newDefect / ftecount).toFixed(2);
                $("#totalincident").text(totalincident);
                $("#hdvrnumberper").text(teamfte);
                //k++;
                //alert(teamfte);
                $("#ndvr").text(newDefect);
                $("#devrequest").text(devRequest);
                //$("#ndvrnumberper").text(((newDefect / (totalincident - devRequest)) * 100).toFixed(2) + "%");
                $("#ndvrnumberper").text((((newDefect-ndApriltoJan)  / (totalincident - tdApriltoJan - devRequest)) * 100).toFixed(2) + "%");
				$("#hdvrnumberper").text(((highDefect / (newDefect)) * 100).toFixed(2) + "%");
                //$("#hdvr").text((newDefect/ftecount).toFixed(2));
                $("#usernamevalue").text(teamfte);
                $.each(json, function(key, value) {
                    //alert(json[key][1]);
                    if (value === "" || value === null || json[key][1] == "0" || json[key][1] == 0) {
                        delete json[key];
                        //alert(json[key]);
                    }
                });
                json = json.filter(function(x) {
                    return x !== null
                });
                //alert(json);
                options.series[0].data = json;
                chart = new Highcharts.Chart(options);
                //alert(json[1][1]);
                //alert(categoryDefect[2]);		
            });
    }

    return categoryDefect;
}