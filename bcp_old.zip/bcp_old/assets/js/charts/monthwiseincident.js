var k=0
var chart1=null;
var currentRequest3=null;
 var createTable = function($chart) {
        
        console.log("$series = %o", $chart);
        
        // remove the existing table
        $('#table123 tr').remove();
        
        // create a table object
        var table = $('<table id="table12" class="table table-bordered" style="display:none;"></table>').addClass('chart-table');
        var row=new Array();
		var j=1;
        // iterate the series object, create rows and columnts
				  row[0] = $('<tr></tr>').addClass('chart-row');
				  $('<td style="font-weight:bold;"></td>').text("Month").appendTo(row[0]);
				  $('<td style="font-weight:bold;"></td>').text("Incident Created").appendTo(row[0]);
				  $('<td style="font-weight:bold;"></td>').text("Incident Confirmed").appendTo(row[0]);
				  $('<td style="font-weight:bold;"></td>').text("New Defect").appendTo(row[0]);
				  $('<td style="font-weight:bold;"></td>').text("Devlopment Request").appendTo(row[0]);
				
		for (var i = 0; i <= 3; i++) {
		if($chart.series[i]!=null)
        $.each($chart.series[i].data, function( index, value ) {
			 //console.log(value);
			 var str='chart-row'+j;
			 if(i==0){
				row[j] = $('<tr></tr>').addClass(str);
			 }
			 
			 if(i==0){
				//row[j] = $('<tr></tr>').addClass(str);
				var col1 = $('<td style="font-weight:bold;"></td>').text(value.category).appendTo(row[j]);
			 }
            var col2 = $('<td></td>').text(value.y).appendTo(row[j]);
			
			j++;
			
			//alert(value.category);
            //var col2 = $('<td></td>').text(value.percentage).appendTo(row);
            
            // mark the row of the clicked sector
            //if ($chart.name == value.name)
              //  row.addClass('selected');
            
            
        });
		j=1;
		}
		table.append(row);
		
		//alert("test");
		$('#table123').append(table);
		
		$("#table123").each(function() {
        var $this = $(this);
        var newrows = [];
        $this.find("tr").each(function(){
            var i = 0;
            $(this).find("td").each(function(){
                i++;
                if(newrows[i] === undefined) { newrows[i] = $("<tr></tr>"); }
                newrows[i].append($(this));
            });
        });
        $this.find("tr").remove();
        $.each(newrows, function(){
            $this.append(this);
        });
    });
	if(document.getElementById('user2').options[document.getElementById('user2').selectedIndex])
				var text=document.getElementById('user2').options[document.getElementById('user2').selectedIndex].text;
			else
				var text="Excel";
	
		$("#table123").table2excel({
			exclude: ".noExl",
			//name: "Worksheet Name",
			//filename: document.getElementById('user2').options[document.getElementById('user2').selectedIndex].text
			filename:text
			
		});

 }
  function removeItem(array, item){
    for(var i in array){
        if(array[i]==item){
            array.splice(i,1);
            break;
        }
    }
}
    
   function graphteamusers(ids,role,start_Date,end_Date,loggeduser) {
 //alert(start_Date);
	//alert(ids);


	removeItem(ids, '0');
	
            var options = {
        chart: {
			
            renderTo: 'container2',
			zoomType: 'x',
            type: 'column',
			"height": 500,
			 margin: 120,
            /*options3d: {
				enabled: true,
                alpha: 0,
                beta: 0,
                depth: 50
            }*/
			
        },
		legend: {
            itemStyle: {
                
                fontWeight: 'normal',
                fontSize: '11px'
            }
        },
		
		yAxis: {
		//max: 5,
		title: 
		  {
           text: 'Incidents'
          },
		},
		
        xAxis: {
			
		
            categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
			crosshair: true
        },
		
		credits: {
           enabled: false
        },
        title:{
		    text: ''
		},
		tooltip: {
			headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
				'<td style="padding:0"><b>{point.y:.0f} </b></td></tr>',
			footerFormat: '</table>',
			shared: true,
			useHTML: true,
		   
	    },
		"labels": {
			
            "enabled": true,
            "format": "{value}%"
        },
		
				
		plotOptions: {
			
		        	column: {
							point: {
						events: {
					    click: function() {
                            createTable(chart1);
                        },
                     
					}
                    
                },
						
					pointPadding: 0.1,
            borderWidth: 0,
			//pointWidth: 12,
            	zones: [{
                	//value: 2.5, // Values up to 10 (not including) ...
                    //color: 'red' // ... have the color blue.
                }]
            },

                series: {  
				
				animation: true,		 // start up animation turned OFF		
                cursor: 'pointer',
                point: {
				events: {
                     
					}
                    
                }
            }
        },
		
		            
        series: []
		}
		
		//alert(ids);
		
			//alert(quotedIds);
		if(role==2){
			var quotedIds = [];
			for (var i = 0; i < ids.length; ++i)
				quotedIds.push("'" + ids[i] + "'");
			quotedIds = quotedIds.join(", ");
			//alert("cost="+quotedIds);
			$.getJSON('/assets/php/Manager/datateamman.php', {ids : quotedIds,
											start_Date : start_Date,
											end_Date : end_Date,
											loggeduser : loggeduser}, function(json) {
				//options.xAxis.categories = json[0]['data'];
                options.series[0] = json[0];
				options.series[1] = json[1];
				options.series[2] = json[2];
				options.series[3] = json[3];
				//options.chart.type = 'column';
				chart = new Highcharts.Chart(options);
				chart1=chart;
				});
		}
		else if(role==0){
			var quotedIds = [];
			for (var i = 0; i < ids.length; ++i)
				quotedIds.push("'" + ids[i] + "'");
			quotedIds = quotedIds.join(", ");
			//alert("cost="+quotedIds);
			//alert("test");
				$.getJSON('/assets/php/User/datateamuser.php', {ids : quotedIds,
											start_Date : start_Date,
											end_Date : end_Date,
											loggeduser : loggeduser}, function(json) {
				//options.xAxis.categories = json[0]['data'];
                options.series[0] = json[0];
				options.series[1] = json[1];
				options.series[2] = json[2];
				options.series[3] = json[3];
				//options.chart.type = 'column';
				chart = new Highcharts.Chart(options);
				chart1=chart;
				});
		}
		else{
			var quotedIds = [];
			for (var i = 0; i < ids.length; ++i)
				quotedIds.push( ids[i] );
			quotedIds = quotedIds.join(", ");
			quotedIds = quotedIds.replace(/,\s*$/, "");
			//alert("cost="+ids.length);
			//alert("test= "+start_Date);
			currentRequest3 = $.ajax({
            url: "/assets/php/Head/dataheadteam.php",
            type: "GET",
            dataType: 'json',
            data: {
                ids: quotedIds,
                start_Date: start_Date,
                end_Date: end_Date,
				len: ids.length
            },
            beforeSend: function() {
                if (currentRequest3 != null) {
                    //alert("test");
                    currentRequest3.abort();
                }
            },
            complete: function() {
                currentRequest3 = null;
            },
            success: function(json) {
				//options.xAxis.categories = json[0]['data'];
				$('.loader').hide();
                options.series[0] = json[0];
				options.series[1] = json[1];
				options.series[2] = json[2];
				//options.series[3] = json[3];
				//options.chart.type = 'column';
				chart = new Highcharts.Chart(options);
				chart1=chart;
				}
			});
		}
				
}