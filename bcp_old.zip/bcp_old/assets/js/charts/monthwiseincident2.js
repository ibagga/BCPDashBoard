var k=0

   $(document).ready(function() {
 
            var options = {
        chart: {
			
            renderTo: 'container3',
			zoomType: 'x',
            type: 'column',
			"height": 400,
			"width":750,
			 margin: 80,
            /*options3d: {
				enabled: true,
                alpha: 0,
                beta: 0,
                depth: 50
            }*/
			
        },
		legend: {
            itemStyle: {
                
                fontWeight: 'normal',
                fontSize: '11px'
            }
        },
		
		yAxis: {
		//max: 5,
		title: 
		  {
           text: 'Incidents'
          },
		},
		
        xAxis: {
			
		
            categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
			crosshair: true
        },
		
		credits: {
           enabled: false
        },
        title:{
		    text: ''
		},
		tooltip: {
			headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
				'<td style="padding:0"><b>{point.y:.0f} </b></td></tr>',
			footerFormat: '</table>',
			shared: true,
			useHTML: true,
		   
	    },
		"labels": {
			
            "enabled": true,
            "format": "{value}%"
        },
		
		
		
		
		plotOptions: {
			
		        	column: {
					pointPadding: 0.1,
            borderWidth: 0,
			//pointWidth: 12,
            	zones: [{
                	//value: 2.5, // Values up to 10 (not including) ...
                    //color: 'red' // ... have the color blue.
                }]
            },

                series: {  
				
				animation: true,		 // start up animation turned OFF		
                cursor: 'pointer',
                point: {
				events: {
                     
					}
                    
                }
            }
        },
		
		            
        series: []
		}
		
		
		$.getJSON("datateamuser.php", function(json) {
		
                
				options.chart.type = 'column';
                
                chart = new Highcharts.Chart(options);
				$.getJSON('datateamuser.php', function(json) {
				//options.xAxis.categories = json[0]['data'];
                options.series[0] = json[1];
				options.series[1] = json[2];
				options.series[2] = json[3];
				//options.chart.type = 'column';
				chart = new Highcharts.Chart(options);
				});
				
				
			 });
});
	
	

