var k=0

   function graphteamusersstart(ids,role,start_Date,end_Date) {
 //alert(start_Date);
            var options = {
        chart: {
			
            renderTo: 'container2',
			zoomType: 'x',
            type: 'column',
			"height": 500,
			 margin: 120,
            /*options3d: {
				enabled: true,
                alpha: 0,
                beta: 0,
                depth: 50
            }*/
			
        },
		legend: {
            itemStyle: {
                
                fontWeight: 'normal',
                fontSize: '11px'
            }
        },
		
		yAxis: {
		//max: 5,
		title: 
		  {
           text: 'Incidents'
          },
		},
		
        xAxis: {
			
		
            categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
			crosshair: true
        },
		
		credits: {
           enabled: false
        },
        title:{
		    text: ''
		},
		tooltip: {
			headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
				'<td style="padding:0"><b>{point.y:.0f} </b></td></tr>',
			footerFormat: '</table>',
			shared: true,
			useHTML: true,
		   
	    },
		"labels": {
			
            "enabled": true,
            "format": "{value}%"
        },
		
				
		plotOptions: {
			
		        	column: {
						
					pointPadding: 0.1,
            borderWidth: 0,
			//pointWidth: 12,
            	zones: [{
                	//value: 2.5, // Values up to 10 (not including) ...
                    //color: 'red' // ... have the color blue.
                }]
            },

                series: {  
				
				animation: true,		 // start up animation turned OFF		
                cursor: 'pointer',
                point: {
				events: {
                     
					}
                    
                }
            }
        },
		
		            
        series: []
		}
		
		//alert(ids);
		
			//alert(quotedIds);
		if(role==0){
			var quotedIds = [];
			for (var i = 0; i < ids.length; ++i)
				quotedIds.push("'" + ids[i] + "'");
			quotedIds = quotedIds.join(", ");
			//alert("cost="+quotedIds);
			//alert("test");
				$.getJSON('/assets/php/start/datateamuserstart.php', {ids : quotedIds,
											start_Date : start_Date,
											end_Date : end_Date}, function(json) {
				//options.xAxis.categories = json[0]['data'];
                options.series[0] = json[0];
				options.series[1] = json[1];
				options.series[2] = json[2];
				options.series[3] = json[3];
				//options.chart.type = 'column';
				chart = new Highcharts.Chart(options);
				});
		}
		else{
			var quotedIds = [];
			for (var i = 0; i < ids.length; ++i)
				quotedIds.push( ids[i] );
			quotedIds = quotedIds.join(", ");
			quotedIds = quotedIds.replace(/,\s*$/, "");
			//alert("cost="+quotedIds);
			//alert("test= "+start_Date);
				$.getJSON('/assets/php/start/dataheadteamstart.php', {ids : quotedIds,
											start_Date : start_Date,
											end_Date : end_Date}, function(json) {
				//options.xAxis.categories = json[0]['data'];
                options.series[0] = json[0];
				options.series[1] = json[1];
				options.series[2] = json[2];
				options.series[3] = json[3];
				//options.chart.type = 'column';
				chart = new Highcharts.Chart(options);
				});
		}
				
}