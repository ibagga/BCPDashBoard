var k=0;
var teamfte=0

// Radialize the colors
  Highcharts.getOptions().colors = Highcharts.map(Highcharts.getOptions().colors, function (color) {
      return {
          radialGradient: {
              cx: 0.5,
              cy: 0.3,
              r: 0.7
          },
          stops: [
              [0, color],
              [1, Highcharts.Color(color).brighten(-0.2).get('rgb')] // darken
          ]
      };
  });
    

   function piedefectstart(ids,role,start_Date,end_Date,ftecount) {
	   var categoryDefect=[];
///////////////	   alert(end_Date);
   var options = {
      chart: {
		  renderTo: 'container3',
          plotBackgroundColor: null,
          plotBorderWidth: true,
          plotShadow: false,
          type: 'pie',
		  height:500,
		  margin: 30,
		  showInLegend: true
      },
	  legend: {
            itemStyle: {
                
                fontWeight: 'normal',
                fontSize: '11px'
            }
      },
	  credits: {
           enabled: false
      },
	title: {
        text: '',
		fontSize: '9px',
		fontWeight: 'bold',
    },
      subtitle: {
        text: 'Defect Categorization',
		fontSize: '9px',
		fontWeight: 'bold',
		y: 480
    },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.y:.0f}, {point.percentage:.1f} %</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.y:.0f}, {point.percentage:.1f} %',
                  style: {fontWeight: 'normal',
                      color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                  },
                  connectorColor: 'silver'
              }
          }
      },
      series: [{
		type: 'pie',
		name: 'Defect share',
		data: []
	  }]
	  
  }
  
  if(role==0){
	  var quotedIds = [];
	 for (var i = 0; i < ids.length; ++i)
		quotedIds.push("'" + ids[i] + "'");
	quotedIds = quotedIds.join(", ");
		//alert(quotedIds);
	$.getJSON('/assets/php/start/piedefectteamuserstart.php', {ids : quotedIds,
										start_Date : start_Date,
										end_Date : end_Date},
	function(json) {
		options.series[0].data = json;
		chart = new Highcharts.Chart(options);
	}); 
  }
  else{
	  var quotedIds = [];
	  for (var i = 0; i < ids.length; ++i)
		quotedIds.push( ids[i] );
	  quotedIds = quotedIds.join(", ");
	  quotedIds = quotedIds.replace(/,\s*$/, "");
	$.getJSON('/assets/php/start/piedefectheadteamstart.php', {ids : quotedIds,
										start_Date : start_Date,
										end_Date : end_Date},
	function(json) {
		//alert(ids);
		categoryDefect[0] = json[0][1] + json[1][1] + json[2][1] + json[3][1] + json[4][1] + json[5][1] + json[6][1] + json[7][1];
		categoryDefect[1] = json[3][1];
		categoryDefect[2] = json[1][1];
		totalincident = categoryDefect[0];
		newDefect = categoryDefect[1];
		devRequest = categoryDefect[2];
		$("#totalincident").text(totalincident);
		//alert(ids);
		if(ids.length==10){
			if($("#checkbox").is(':checked') )
				$('#select2-chosen-1').text("All Selected");
			else
				$('#select2-chosen-1').text("Select a Team");
			teamfte=(newDefect/ftecount).toFixed(2);
		}
		$("#hdvrnumberper").text(teamfte);
		//k++;
	  ////alert(k);
		$("#ndvr").text(newDefect);
		$("#devrequest").text(devRequest);
		$("#ndvrnumberper").text((newDefect/totalincident*100).toFixed(2)+"%");
		$("#hdvr").text((newDefect/ftecount).toFixed(2));
		
		$.each(json, function(key, value){
			//alert(json[key][1]);
		if (value === "" || value === null || json[key][1] == "0"|| json[key][1] == 0){
			delete json[key];
			//alert(json[key]);
		}
		});
		json = json.filter(function(x) { return x !== null }); 
		//alert(json);
		options.series[0].data = json;
		chart = new Highcharts.Chart(options);
		//alert(json[1][1]);
		//alert(categoryDefect[2]);		
	});
  }
	
	return categoryDefect;
  
   }