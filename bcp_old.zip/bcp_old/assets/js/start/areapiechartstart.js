var k=0



   function drawChartstart(ids,role,start_Date,end_Date) {
	   
///////////////	   alert(end_Date);
   var options = {
      chart: {
		  renderTo: 'programareachart',
          plotBackgroundColor: null,
          plotBorderWidth: true,
          plotShadow: false,
          type: 'pie',
		  height: 400,
		  margin: 30,
		  showInLegend: true
      },
	  legend: {
            itemStyle: {
                
                fontWeight: 'normal',
                fontSize: '11px'
            }
      },
	  title: {
        text: '',
		fontSize: '9px',
		fontWeight: 'bold',
		},
      subtitle: {
        text: 'Defects per Program',
		fontSize: '9px',
		fontWeight: 'bold',
		y: 380
		},
	  credits: {
           enabled: false
      },
      title: {
        text: ''
    },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.y:.0f}, {point.percentage:.1f} %</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.y:.0f}, {point.percentage:.1f} %',
                  style: {fontWeight: 'normal',
                      color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                  },
                  connectorColor: 'silver'
              }
          }
      },
      series: [{
		type: 'pie',
		name: 'Defect share',
		data: []
	  }]
	  
  }
  
  if(role==0){
	  var quotedIds = [];
	 for (var i = 0; i < ids.length; ++i)
		quotedIds.push("'" + ids[i] + "'");
	quotedIds = quotedIds.join(", ");
		//alert(quotedIds);
	$.getJSON('/assets/php/start/programareateamuserchartstart.php', {ids : quotedIds,
										start_Date : start_Date,
										end_Date : end_Date},
	function(json) {
		options.series[0].data = json;
		chart = new Highcharts.Chart(options);
	}); 
  }
  else{
	  var quotedIds = [];
	  for (var i = 0; i < ids.length; ++i)
		quotedIds.push( ids[i] );
	  quotedIds = quotedIds.join(", ");
	  quotedIds = quotedIds.replace(/,\s*$/, "");
		
	$.getJSON('/assets/php/start/programareaheadteamchartstart.php', {ids : quotedIds,
										start_Date : start_Date,
										end_Date : end_Date},
	function(json) {
		$('.loader').hide();
		options.series[0].data = json;
		chart = new Highcharts.Chart(options);
		
		
	});
  }

  
   }