var loggedUser;
var role;
var start_Date = $('.daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
var end_Date = $('.daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');
var ndavg=0;
var currentRequest = null;

//get privilege of user
function privilege(id) {
    var re = null;
    //////////alert(id);
    $.ajax({
        async: false,
        url: "../assets/php/getRole.php",
        type: "POST",
        global: false,
        data: {
            id: id
        },
        cache: false,
        success: function(Result) {
            //alert(Result);
            re = Result;
            //alert (re);
        }
    });
    //alert(re);
    return re;

}

//get selected from drop down
function getSelected() {
    var data = [];
    var name = [];

    $('.checked', this.select).each(function() {
        data.push($(this).val());
        name.push($(this).text());
    });
    //alert(name);
    //return data;
    var uniqueNames = [];
    var uniqueData = [];
    $.each(name, function(i, el) {
        if ($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
    });
    $.each(data, function(i, el) {
        if ($.inArray(el, uniqueData) === -1) uniqueData.push(el);
    });
    data = uniqueData;
    name = uniqueNames;
    //alert(uniqueData);
    return {
        data: data,
        name: name
    };
}

////////////////////TEAM USERS DATA -------------MANAGER LEVEL			
function getData(start_Date, end_Date) {
	
    var id = [];
    var name = [];
    var ajaxData = [];
    id = getSelected().data.filter(String);
    name = getSelected().name;
    //alert(loggedUser);
	if(id=="" || id=="0"){
			
			$("#user option").addClass( 'checked' );
			//$("#user").trigger("change");
			id = getSelected().data;
			name = getSelected().name;
			$("#user > option").removeClass( 'checked' );
		}
    var jsonString = JSON.stringify(id);
    $.ajax({
        url: "../assets/php/mangerfte.php",
        type: "POST",
        data: {
            data: jsonString,
            start_Date: start_Date,
            end_Date: end_Date,
			loggedUser:loggedUser
        },
        cache: false,
        beforeSend: function() {
			$("#username").text("NewDefect/FTE");
            $('.loader').show()
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function(Result) {
			if(id=="")
				$("#select2-chosen-1").text("Select a User");
  
			Result = $.parseJSON(Result);
			var hdvr = ((Result[2] / Result[1]) * 100).toFixed(1);
			if (hdvr == "NaN")
                hdvr = 0;
            //////////////recheck/////////////////alert(Result);

            $("#hdvr").text(Result[2]);
            //$("#devrequest").text(Result[3]);
            $("#hdvrnumberper").text(hdvr + "%");
           // $("#devrequestper").text(devreq + "%");
            //$("#username").text(name);
            //$("#username").text(name);
            

            piedefectteam(loggedUser,id, 0, start_Date, end_Date,Result[10]);
            drawChartteam(loggedUser,id, 0, start_Date, end_Date);

        }


    });
    graphteamusers(id, 0, start_Date, end_Date,loggedUser);
    //$('#s2id_user2').hide();
}

////////////////////TEAM DATA -------------Rishabh LEVEL	
function getteamData(ManagerInos, start_Date, end_Date) {


    var ManagerInos = [];
    var name = [];
    var ajaxData = [];
    //var managerUser="";
    var jsonString = "";
    if (ManagerInos == "novalue") {  //redundant
        //alert(costcenter);
        var jsonString = ManagerInos;

        //alert(jsonString);
    } else {

        ManagerInos = getSelected().data;
        name = getSelected().name;
        //alert(ManagerInos);
		if(ManagerInos=="" || ManagerInos=="0"){
			//alert(ManagerInos);
			$("#user option").addClass( 'checked' );
			//$("#user").trigger("change");
			ManagerInos = getSelected().data;
			name = getSelected().name;
			$("#user > option").removeClass( 'checked' );
		}
		
		
		$('#username').text("Click here to view selected Managers");
		$('#username').attr('data-content', name.join(", "));
        jsonString = JSON.stringify(ManagerInos);
        //alert(ManagerInos);
        //alert(jsonString);
        //jsonString = jsonString.replace(/[{()}]/g, '');
        managerUser = ("'" + ManagerInos.join("','") + "'");
        //alert(managerUser );
        if (managerUser == "'0'" || managerUser == "''")
            $('#s2id_user2 > .select2-choice > .select2-chosen').text("No Users Loaded");
        else
            $('#s2id_user2 > .select2-choice > .select2-chosen').text("Select a User");

        $.ajax({
            url: "../assets/php/kathicktouserfilter.php",
            type: "GET",
            dataType: "html",
            data: {
                "data": managerUser
            },
            success: function(Result) {
                //alert(Result);
                $('#user2').empty();
				$('#user2').prepend("<option value='0'>Deselect Users</option>");
                $('#user2').append('<option selected disabled>Selection options</option>');
                $('#user2').append(Result);


            }
        });



    }
    //////////
    //alert(jsonString);
    $('.loader').show();
    

	currentRequest = $.ajax({
        url: "../assets/php/teamdata.php",
        type: "POST",
        data: {
            data: jsonString,
            start_Date: start_Date,
            end_Date: end_Date
        },
        beforeSend: function() {
					 
			if(currentRequest != null) {
				currentRequest.abort();
			}
            $('.loader').show();
        },
        complete: function() {
            //$('.loader').hide()
			currentRequest=null;
        },
        cache: false,
        success: function(Result) {

            var arr = [];
            var i = 0;
            Result = $.parseJSON(Result);
            //////////////recheck/////////////////
            //alert(Result);
            var count = Result[10];
            //alert(count);
          
            $("#hdvrnumberper").text("");
            $("#hdvrname").text("New Defect/FTE");
            $("#hdvrnumber").text("New Defect/FTE at STE Level");
            //devrequest
            //$("#devrequestper").text(devreq+"%");
            //$("#username").text(name);
            //$("#username").text(name);
            //alert(name);
            if (ManagerInos == "novalue") {
                piedefect('', 1, start_Date, end_Date, count);
                drawChart('', 1, start_Date, end_Date);
            } else {
                piedefect(ManagerInos, 1, start_Date, end_Date, count);
				drawChart(ManagerInos, 1, start_Date, end_Date);
                
            }


        }

    });

    if (ManagerInos == "novalue")
        console.log("test");
    else
        graphteamusers(ManagerInos, 1, start_Date, end_Date);
	

}
////////////////////SINGLE USER DATA -------------USER LEVEL	
function getData1(id, start_Date, end_Date) {
	// array id is the I number of the user
    var arrayid = [];
    arrayid[0] = id;
    //var ajaxData=[];
    //id = getSelected().data;
    //name = getSelected().name;
    //alert(id);
    //var jsonString = JSON.stringify(id);
    $.ajax({
        url: "../assets/php/loadsingleuser.php",
        type: "POST",

        data: {
            data: id,
            start_Date: start_Date,
            end_Date: end_Date
        },
        cache: false,
        beforeSend: function() {
            $('.loader').show()
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function(Result) {
            var arr = [];
            var i = 0;
            Result = $.parseJSON(Result);
			//result array contains at corresponding position 
			//array($totalcount, $totalnewdefect, $totalhighdefect, $devreqdefect, $knowndefect, $notreproducibledefect, $consultingdefect, $testdemodefect, $testcasedefect, $otherdefect,$ndJantoAprilF,$totalJantoAprilF );
		
            //////////////recheck/////////////////alert(Result);
			var devreq = ((Result[3] / Result[0]) * 100).toFixed(1);
           // var ndvr = ((Result[1] / (Result[0]-Result[3])) * 100).toFixed(1);
            var hdvr = ((Result[2] / Result[1]) * 100).toFixed(1);
			var ndApriltoJan = Result[10];
			var tdApriltoJan = Result[11];
			console.log("test123 "+ndApriltoJan+" "+tdApriltoJan);
			var ndvr = ((((Result[1]-ndApriltoJan)  / (Result[0] - tdApriltoJan - Result[3])) * 100).toFixed(2));
            
            if (ndvr == "NaN")
                ndvr = 0;
            if (hdvr == "NaN")
                hdvr = 0;
            if (devreq == "NaN")
                devreq = 0;
            $("#totalincident").text(Result[0]);
            $("#ndvr").text(Result[1]);
            $("#hdvr").text(Result[2]);
            $("#devrequest").text(Result[3]);
            $("#ndvrnumberper").text(ndvr + "%");
            $("#hdvrnumberper").text(hdvr + "%");
            $("#devrequestper").text(devreq + "%");
            $("#hdvrname").text("High Defect");
            $("#hdvrnumber").text("High Defect");
            //$("#username").text(name);
            //$("#username").text(name);
            //alert(name);
			console.log("total incident "+Result[0]);
			console.log("ndvr "+Result[1]);
			console.log("dev "+Result[3]);
		
			
			
            piedefect(arrayid, 0, start_Date, end_Date);
            drawChart(arrayid, 0, start_Date, end_Date);

        }

    });
    graphteamusers(arrayid, 0, start_Date, end_Date);
}


//get logged user
function setloggedUser(start_Date, end_Date) {
    $('.loader').show();
    $.post('../assets/php/getUser.php', {},
        function(result) {
            result = result.split("\\");
            loggedUser = result[1];
			//if(loggedUser=="I332712")
				//loggedUser="I057052";
            $("#displayId").append(loggedUser);
            //////////alert(loggedUser);

            role = privilege(loggedUser);
            //////////alert(role);
			//loggedUser="I031726";
			//role="I031726";
            //Kartick role
            if (loggedUser == 'I023588' || loggedUser == 'i023588' || loggedUser == 'I332712' || loggedUser == 'i332712' || loggedUser == 'I065916' || loggedUser == 'i065916' || loggedUser == 'I077219' || loggedUser == 'i077219' || loggedUser == 'I064783' || loggedUser == 'I064783' || loggedUser == 'I065815' || loggedUser == 'i065815' || loggedUser == 'I017766' || loggedUser == 'I017766' || loggedUser == 'C5245550' || loggedUser == 'c5245550'|| loggedUser == 'I029998' || loggedUser == 'i029998'  || loggedUser == 'i055407' || loggedUser == 'I055407' || loggedUser == 'i500503' || loggedUser == 'I500503')  {
                //alert("karthick");
                $('.select2-multiple2').select2MultiCheckboxes({
                    placeholder: "Choose multiple elements"
                });
                $.post('../assets/php/filterSuperuser.php', {},
                    function(result) {
                        $('#user').html(result);
						$("#user option").addClass( 'checked' );
						$("#user").trigger("change");
						$("#user > option").removeClass( 'checked' );
						$("#select2-chosen-1").text("Select a Team");
                    }
                );
           
            }


            // normal user logged in		
            else if (role == 'user') {
				$('#start').css("display","none")
				$('#footer1').css("display","block");
				$('#lobhead').css("display","none");
				$('#userhead').css("display","block");
                //$("#userdrop").hide();
                $('#daterangetext').css("padding-left", "0px");
                $('#user').css("display", "none");
                $('#checkbox').text("");
                $('#checkbox').css("display", "none");
                $('#drop1').css("display", "none");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
                $('#userdrop').css("padding-top", "30px");
                $('#userdrop').css("padding-left", "0px");
                $('#allselect').css("display", "none");
                getData1(loggedUser, start_Date, end_Date);

            }
			else if(role =="startuser")
				window.location.href = "http://localhost/start.html";
			else {
				$('#start').css("display","none")
				$('#lobhead').css("display","none");
				$('#managerhead').css("display","block");
                //alert("Manager");
                $("#select2-chosen-1").text("Select a User");
                $('#drop1').text("STE Engineer :");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
                $('.select2-multiple2').select2MultiCheckboxes({
                    placeholder: "Choose multiple elements"
                });

                $.post('../assets/php/filteruser.php', {
                        data: role
                    },
                    function(result) {
                        $('#user').html(result);
						$("#user option").addClass( 'checked' );
						$("#user").trigger("change");
						$("#user > option").removeClass( 'checked' );
                    }
                );

                $("#select2-chosen-1").text("Select a User");
                //graphteamusers('', 0, start_Date, end_Date);
                //piedefect('', 0, start_Date, end_Date);
                //drawChart('', 0, start_Date, end_Date);
                $('#s2id_user2').hide();
            }


        }

    );


    $('.loader').hide();
}
$(document).ready(function() {
	$('[data-toggle="popover"]').popover();
    var arr = "";
    document.addEventListener('DOMContentLoaded', function() {
       demo.initDashboardPageCharts
    });

    setloggedUser(start_Date, end_Date);
    console.log(start_Date);
    console.log(end_Date);



    //$("#user2").select2();
	// user and daterange change function
    $("#user,.daterange").change(function() {
			ndavg=0;
			document.getElementById("usernamevalue").innerHTML="";
			document.getElementById("username").innerHTML="Username";
            //$("#select2-chosen-12").text("Select a User");
            var start_Date = $('.daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
            var end_Date = $('.daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');
            //alert(role);
			
            if (loggedUser == 'I023588' || loggedUser == 'i023588' || loggedUser == 'I332712' || loggedUser == 'i332712' || loggedUser == 'I065916' || loggedUser == 'i065916' || loggedUser == 'I077219' || loggedUser == 'i077219' || loggedUser == 'I064783' || loggedUser == 'I064783' || loggedUser == 'I065815' || loggedUser == 'i065815' || loggedUser == 'I017766' || loggedUser == 'i017766' || loggedUser == 'C5245550' || loggedUser == 'c5245550'|| loggedUser == 'I029998' || loggedUser == 'i029998'  || loggedUser == 'i055407' || loggedUser == 'I055407' || loggedUser == 'i500503' || loggedUser == 'I500503') {
                $("#user2").select2();
                $('#user2').empty();
                getteamData(loggedUser, start_Date, end_Date);
            } else if (role == 'user') {
                $('#daterangetext').css("padding-left", "0px");
                $('#user').css("display", "none");
                $('#checkbox').text("");
                $('#checkbox').css("display", "none");
                $('#drop1').css("display", "none");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
                $('#allselect').text("");
                $('#userdrop').css("padding-top", "30px");
                getData1(loggedUser, start_Date, end_Date);
            } else {
                
                $('#drop1').text("STE Engineer :");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");

                getData(start_Date, end_Date);
            }

        }

    );

	// user change
    $("#user2").change(function() {
		if(ndavg==0){
			document.getElementById("usernamevalue").innerHTML=document.getElementById("hdvr").innerHTML;
		}
		document.getElementById("username").innerHTML="New Defect per User";
		ndavg++;
        var e = document.getElementById('user2');
        var strSel = "The Value is: " + e.options[e.selectedIndex].value + " and text is: " + e.options[e.selectedIndex].text;
        //alert(strSel);
        //alert(e.options.length);
        var start_Date = $('.daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
        var end_Date = $('.daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');
        //alert(start_Date);
		if(e.options[e.selectedIndex].value==0)
		{
			$('#usernamevalue').text("");
			$('#username').text("Username");
			getteamData(0,start_Date, end_Date);
		}
		else
        getData1(e.options[e.selectedIndex].value, start_Date, end_Date);

    });

});