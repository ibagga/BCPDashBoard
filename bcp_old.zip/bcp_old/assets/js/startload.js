var loggedUser;
var role;
var start_Date = $('.daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
var end_Date = $('.daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');
var ndavg=0;

function privilege(id) {
    var re = null;
    //////////alert(id);
    $.ajax({
        async: false,
        url: "../assets/php/getRole.php",
        type: "POST",
        global: false,
        data: {
            id: id
        },
        cache: false,
        success: function(Result) {
            //alert(Result);
            re = Result;
            //alert (re);
        }
    });
    //alert(re);
    return re;

}

function getSelected() {
    var data = [];
    var name = [];

    $('.checked', this.select).each(function() {
        data.push($(this).val());
        name.push($(this).text());
    });
    //alert(name);
    //return data;
    var uniqueNames = [];
    var uniqueData = [];
    $.each(name, function(i, el) {
        if ($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
    });
    $.each(data, function(i, el) {
        if ($.inArray(el, uniqueData) === -1) uniqueData.push(el);
    });
    data = uniqueData;
    name = uniqueNames;
    //alert(uniqueData);
    return {
        data: data,
        name: name
    };
}

////////////////////TEAM USERS DATA -------------MANAGER LEVEL			
function getData(start_Date, end_Date) {

    var id = [];
    var name = [];
    var ajaxData = [];
    id = getSelected().data.filter(String);
    name = getSelected().name;
    //alert(id);
	if(id=="" || id=="0"){

			$("#user option").addClass( 'checked' );
			//$("#user").trigger("change");
			id = getSelected().data.filter(String);
			name = getSelected().name;
			$("#user > option").removeClass( 'checked' );
	}

    var jsonString = JSON.stringify(id);
    $.ajax({
        url: "../assets/php/start/loadstart.php",
        type: "POST",
        data: {
            data: jsonString,
            start_Date: start_Date,
            end_Date: end_Date
        },
        cache: false,
        beforeSend: function() {
            $('.loader').show()
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function(Result) {
			if(id=="")
				$("#select2-chosen-1").text("Select a User");
            var arr = [];
            var i = 0;
            Result = $.parseJSON(Result);
            //////////////recheck/////////////////alert(Result);
            var ndvr = ((Result[1] / Result[0]) * 100).toFixed(1);
            var hdvr = ((Result[2] / Result[1]) * 100).toFixed(1);
            var devreq = ((Result[3] / Result[0]) * 100).toFixed(1);
            if (ndvr == "NaN")
                ndvr = 0;
            if (hdvr == "NaN")
                hdvr = 0;
            if (devreq == "NaN")
                devreq = 0;
            $("#totalincident").text(Result[0]);
            $("#ndvr").text(Result[1]);
            $("#hdvr").text(Result[2]);
            $("#devrequest").text(Result[3]);
            $("#ndvrnumberper").text(ndvr + "%");
            $("#hdvrnumberper").text(hdvr + "%");
            $("#devrequestper").text(devreq + "%");
            //$("#username").text(name);
            //$("#username").text(name);
            //alert(name);

            piedefectstart(id, 0, start_Date, end_Date);
            drawChartstart(id, 0, start_Date, end_Date);

        }


    });
    graphteamusersstart(id, 0, start_Date, end_Date);
    //$('#s2id_user2').hide();
}


////////////////////SINGLE USER DATA -------------USER LEVEL	
function getData1(id, start_Date, end_Date) {

    var arrayid = [];
    arrayid[0] = id;
    //var ajaxData=[];
    //id = getSelected().data;
    //name = getSelected().name;
    //alert(id);
    //var jsonString = JSON.stringify(id);
    $.ajax({
        url: "../assets/php/start/loadsingleuserstart.php",
        type: "POST",

        data: {
            data: id,
            start_Date: start_Date,
            end_Date: end_Date
        },
        cache: false,
        beforeSend: function() {
            $('.loader').show()
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function(Result) {
            var arr = [];
            var i = 0;
            Result = $.parseJSON(Result);
            //////////////recheck/////////////////alert(Result);
            var ndvr = ((Result[1] / Result[0]) * 100).toFixed(1);
            var hdvr = ((Result[2] / Result[1]) * 100).toFixed(1);
            var devreq = ((Result[3] / Result[0]) * 100).toFixed(1);
            if (ndvr == "NaN")
                ndvr = 0;
            if (hdvr == "NaN")
                hdvr = 0;
            if (devreq == "NaN")
                devreq = 0;
            $("#totalincident").text(Result[0]);
            $("#ndvr").text(Result[1]);
            $("#hdvr").text(Result[2]);
            $("#devrequest").text(Result[3]);
            $("#ndvrnumberper").text(ndvr + "%");
            $("#hdvrnumberper").text(hdvr + "%");
            $("#devrequestper").text(devreq + "%");
            $("#hdvrname").text("High Defect");
            $("#hdvrnumber").text("High Defect");
            //$("#username").text(name);
            //$("#username").text(name);
            //alert(name);

            piedefectstart(arrayid, 0, start_Date, end_Date);
            drawChartstart(arrayid, 0, start_Date, end_Date);

        }

    });
    graphteamusersstart(arrayid, 0, start_Date, end_Date);
}

function setloggedUser(start_Date, end_Date) {
    $('.loader').show();
    $.post('../assets/php/getUser.php', {},
        function(result) {
            result = result.split("\\");
            loggedUser = result[1];
			//loggedUser = 'i027453';
            $("#displayId").append(loggedUser);
            //////////alert(loggedUser);

            role = privilege(loggedUser);
            //////////alert(role);            

            if (loggedUser == 'i332712' || loggedUser == 'I332712'|| loggedUser == 'I055407' || loggedUser == 'i055407'  || loggedUser == 'I064783' || loggedUser == 'i064783' || loggedUser == 'I065815' || loggedUser == 'i065815' || loggedUser == 'I017766' || loggedUser == 'i017766' || loggedUser == 'I027453' || loggedUser == 'i027453' ) {
            	$('#lobhead').css("display","none");
				$('#managerhead').css("display","block");
                //alert("Manager");
                $("#select2-chosen-1").text("Select a User");
                $('#drop1').text("STE Engineer :");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
				$("#user2").removeClass("js-example-basic-multiple");
                $('.select2-multiple2').select2MultiCheckboxes({
                    theme: "classic",
					
                });
				
                $('#s2id_user2').hide();
                $.post('../assets/php/filteruser.php', {
                        data: 'I027453'
                    },
                    function(result) {
                        $('#user').html(result);
						$("#user option").addClass( 'checked' );
						$("#user").trigger("change");
						$("#user > option").removeClass( 'checked' );
						$("#select2-chosen-1").text("Select a User");
                    }
                );

                
            }
			// normal user logged in		
            else if (role == 'user') {
				$('#lobhead').css("display","none");
				$('#userhead').css("display","block");
                //$("#userdrop").hide();
                $('#daterangetext').css("padding-left", "0px");
                $('#user').css("display", "none");
                $('#checkbox').text("");
                $('#checkbox').css("display", "none");
                $('#drop1').css("display", "none");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
                $('#userdrop').css("padding-top", "30px");
                $('#userdrop').css("padding-left", "0px");
                $('#allselect').css("display", "none");
                getData1(loggedUser, start_Date, end_Date);

            }
			else{
				$('#lobhead').css("display","none");
				$('#userhead').css("display","block");
                //$("#userdrop").hide();
                $('#daterangetext').css("padding-left", "0px");
                $('#user').css("display", "none");
                $('#checkbox').text("");
                $('#checkbox').css("display", "none");
                $('#drop1').css("display", "none");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
                $('#userdrop').css("padding-top", "30px");
                $('#userdrop').css("padding-left", "0px");
                $('#allselect').css("display", "none");
				$('.select2-multiple2').select2MultiCheckboxes({
                    theme: "classic",
					placeholder: "Select a User"
                });
				
			}


        }

    );


    $('.loader').hide();
}
$(document).ready(function() {
	$('[data-toggle="popover"]').popover();
    var arr = "";
    document.addEventListener('DOMContentLoaded', function() {
        /*Your chartist initialization code here*/

        demo.initDashboardPageCharts


    });

    //drawChart();
	
	
    setloggedUser(start_Date, end_Date);
	//alert( moment().format('DD/MM/YYYY'));
	
	
    console.log(start_Date);
    console.log(end_Date);



    //$("#user2").select2();
    $("#user,.daterange").change(function() {
			ndavg=0;
			document.getElementById("usernamevalue").innerHTML="";
			document.getElementById("username").innerHTML="Username";
            //$("#select2-chosen-12").text("Select a User");
            var start_Date = $('.daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
            var end_Date = $('.daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');
            //alert(role);
			
            if (loggedUser == 'i332712' || loggedUser == 'I332712'|| loggedUser == 'I055407' || loggedUser == 'i055407'  || loggedUser == 'I064783' || loggedUser == 'i064783' || loggedUser == 'I065815' || loggedUser == 'i065815' || loggedUser == 'I017766' || loggedUser == 'i017766' || loggedUser == 'I027453' || loggedUser == 'i027453' ) {
                
                $('#drop1').text("STE Engineer :");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");

                getData(start_Date, end_Date);
            }
			else if (role == 'user') {
                $('#daterangetext').css("padding-left", "0px");
                $('#user').css("display", "none");
                $('#checkbox').text("");
                $('#checkbox').css("display", "none");
                $('#drop1').css("display", "none");
                $('#drop2').css("display", "none");
                $('#user2').css("display", "none");
                $('#allselect').text("");
                $('#userdrop').css("padding-top", "30px");
                getData1(loggedUser, start_Date, end_Date);
            }

        }

    );

    $("#user2").change(function() {
		if(ndavg==0){
			document.getElementById("usernamevalue").innerHTML=document.getElementById("hdvr").innerHTML;
		}
		document.getElementById("username").innerHTML="New Defect per User";
		ndavg++;
        var e = document.getElementById('user2');
        var strSel = "The Value is: " + e.options[e.selectedIndex].value + " and text is: " + e.options[e.selectedIndex].text;
        //alert(strSel);
        //alert(e.options.length);
        var start_Date = $('.daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
        var end_Date = $('.daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');
        //alert(start_Date);
		if(e.options[e.selectedIndex].value==0)
		{
			$('#usernamevalue').text("");
			$('#username').text("Username");
			getteamData(0,start_Date, end_Date);
		}
		else
        getData1(e.options[e.selectedIndex].value, start_Date, end_Date);

    });

});