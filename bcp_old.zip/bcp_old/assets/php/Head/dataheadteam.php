<?php
$con = mysqli_connect("127.0.0.1", "root", "", "bcp");

if (!$con)
{
	die('Could not connect: ' . mysqli_error());
}

$empty = 1;

// echo '<script>console.log("'.$empty.'")</script>';

$len = $_GET['len'];

if (empty($_GET['ids']))
{
	$empty = 1;
}
else
{
	$empty = 0;
	$ids = $_GET['ids'];
	$ids = explode(",", $ids);
	$ids = str_replace(' ', '', $ids);
}

$start_Date = $_GET['start_Date'];
$end_Date = $_GET['end_Date'];
$mon = str_split($start_Date, 4);

// echo '<script>console.log("'.$mon[0].'");</script>';
// $ids  = json_decode("$ids", true);
// echo '<script>console.log("'.count($ids).'");</script>';

$rowst = array();
$rows = array();
//$rowst1 = array();
$rows1 = array();
$rowst2 = array();
$rows2 = array();
$rowst3 = array();
$rows3 = array();
$rowst['name'] = 'New Defect';
//$rowst1['name'] = 'Development Request';
$rowst2['name'] = 'Incident Confirmed';
$rowst3['name'] = 'Incident Created';
$t = 1;
$all = array();

// echo '<script>console.log("'.count($ids).'");</script>';

if ($len != 10)
{
	while ($t <= 12)
	{
		$rows['data'][$t] = 0;
		$rows1['data'][$t] = 0;
		$rows2['data'][$t] = 0;
		$rows3['data'][$t] = 0;
		$t++;
	}

	foreach($ids as $temp)
	{
		$temp = str_replace("'", "", $temp);
		$query = "SELECT UserId, DOJ, LWD FROM steall where ManagerId='$temp'";
		$data = mysqli_query($con, $query);

		// echo '<script>console.log("test1")</script>';
		// echo '<script>console.log("'.$temp.'")</script>';

		if (mysqli_num_rows($data))
		{

			while ($row = mysqli_fetch_assoc($data))
			{
				// echo '<script>alert("'.$row['id'].'")</script>';
				// $id=$row['UserId'];
				// echo '<script>console.log("'.$row['UserId'].'")</script>';
				
				// all <- i332712 doj lwd

				$test[0] = $row['UserId'];
				$test[1] = $row['DOJ'];
				$test[2] = $row['LWD'];
				array_push($all, $test);
			}
		}

		foreach($all as $key => $tmp)
		{
			$user_start_date = $tmp[1];
			$user_end_date = $tmp[2];

			// echo '<script>console.log("'.$user_end_date.'")</script>';
			// $testq="SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'New Defect' and SUBSTRING(updation, 1, 4) = '$mon[0]' and  userid= '$tmp' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) ";
			// echo '<script>console.log("'.$testq.'")</script>';
			// monmth cal SUBSTRING(updation, 6, 2)  2018-06-02

			$sth = mysqli_query($con, "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'New Defect' and SUBSTRING(updation, 1, 4) = '$mon[0]' and  userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) order by MONTH asc");

			// $sth1 = mysqli_query($con , "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'Development Request' and SUBSTRING(updation, 1, 4) = '$mon[0]' and userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) ");
			// when where incident confirmed/updated

			$sth2 = mysqli_query($con, "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where SUBSTRING(updation, 1, 4) = '$mon[0]' and userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) ");

			// when where incident created

			$sth3 = mysqli_query($con, "SELECT count(id), SUBSTRING(creation, 6, 2) as MONTH FROM incident where SUBSTRING(creation, 1, 4) = '$mon[0]' and userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(creation, 6, 2) ");

			// echo '<script>console.log("'.$testq.'")</script>';
			// $rr = mysqli_fetch_array($sth);
			// $rr1 = mysqli_fetch_array($sth1);
			// $rr2 = mysqli_fetch_array($sth2);
			// $rr3 = mysqli_fetch_array($sth3);
			// echo '<script> console.log("'.$p.'");</script>';

			while ($rr = mysqli_fetch_array($sth))
			{
				$t = $rr['MONTH'];
				$rows['data'][$t] = $rows['data'][$t] + $rr['count(id)'];
			}

			/*
			while($rr1 = mysqli_fetch_array($sth1))
			{
			$t=$rr1['MONTH'];
			if(($rr1['count(id)']))
			$rows1['data'][$t] = $rows1['data'][$t] + $rr1['count(id)'];
			}

			*/
			while ($rr2 = mysqli_fetch_array($sth2))
			{
				$t = $rr2['MONTH'];
				$rows2['data'][$t] = $rows2['data'][$t] + $rr2['count(id)'];
			}

			while ($rr3 = mysqli_fetch_array($sth3))
			{
				$t = $rr3['MONTH'];
				$rows3['data'][$t] = $rows3['data'][$t] + $rr3['count(id)'];
			}
		}

		$all = array();
		
		//$txs1 = $rows['data']["01"];
		// echo '<script>console.log("'.$txs1.'");</script>';

	}

	$t = 1;
	$p = sprintf('%02d', $t);
	while ($t <= 12)
	{
		$rowst['data'][] = $rows['data'][$p];
		//$rowst1['data'][] = $rows1['data'][$p];
		$rowst2['data'][] = $rows2['data'][$p];
		$rowst3['data'][] = $rows3['data'][$p];
		$t++;
		$p = sprintf('%02d', $t);
	}

	$t = 1;
}

// first time load

else
{
	$query = "SELECT Distinct(UserId) FROM steall ";
	$data = mysqli_query($con, $query);

	// echo '<script>console.log("test1")</script>';
	// echo '<script>console.log("'.$tmp.'")</script>';

	if (mysqli_num_rows($data))
	{

		// echo '<script>console.log("test2")</script>';

		while ($row = mysqli_fetch_assoc($data))
		{

			// echo '<script>alert("'.$row['id'].'")</script>';
			// $id=$row['UserId'];
			// echo '<script>console.log("'.$row['UserId'].'")</script>';

			$test[0] = $row['UserId'];

			// $test[1] = $row['DOJ'];
			// $test[2] = $row['LWD'];

			array_push($all, $test);

			// echo '<script>console.log("'.$test[0].'= '.$test[1].'")</script>';

		}
	}

	foreach($all as $key => $tmp)
	{

		// echo '<script>console.log("   '.$tmp[0].'")</script>';

		$user_start_date = 0;
		$user_end_date = 0;
		$user_start_date = mysqli_query($con, " SELECT min(DOJ) as DOJ FROM steall where UserId = '$tmp[0]' ");
		$user_end_date = mysqli_query($con, " SELECT max(LWD) as LWD FROM steall where UserId = '$tmp[0]' ");
		$user_start_date = mysqli_fetch_assoc($user_start_date);
		$user_end_date = mysqli_fetch_assoc($user_end_date);
		$user_start_date = $user_start_date['DOJ'];
		$user_end_date = $user_end_date['LWD'];

		// echo '<script>console.log("'.$user_end_date.'")</script>';
		// $testq="SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'New Defect' and SUBSTRING(updation, 1, 4) = '$mon[0]' and  userid= '$tmp' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) ";
		// echo '<script>console.log("'.$testq.'")</script>';
		// $sth = mysqli_query($con , "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'New Defect' and SUBSTRING(updation, 1, 4) = '$mon[0]' and  userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) order by MONTH asc");

		$sth = mysqli_query($con, "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'New Defect' and SUBSTRING(updation, 1, 4) = '$mon[0]' and  userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by SUBSTRING(updation, 6, 2) order by MONTH asc");

		// $sth1 = mysqli_query($con , "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'Development Request' and SUBSTRING(updation, 1, 4) = '$mon[0]' and userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date'  group by SUBSTRING(updation, 6, 2) ");

		$sth2 = mysqli_query($con, "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where SUBSTRING(updation, 1, 4) = '$mon[0]' and userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date'  group by SUBSTRING(updation, 6, 2) ");
		$sth3 = mysqli_query($con, "SELECT count(id), SUBSTRING(creation, 6, 2) as MONTH FROM incident where SUBSTRING(creation, 1, 4) = '$mon[0]' and userid= '$tmp[0]' and creation BETWEEN '$user_start_date' AND '$user_end_date'  group by SUBSTRING(creation, 6, 2) ");

		// echo '<script>console.log("'.$testq.'")</script>';
		// $rr = mysqli_fetch_array($sth);
		// $rr1 = mysqli_fetch_array($sth1);
		// $rr2 = mysqli_fetch_array($sth2);
		// $rr3 = mysqli_fetch_array($sth3);
		// echo '<script> console.log("'.$p.'");</script>';

		while ($rr = mysqli_fetch_array($sth))
		{
			$t = $rr['MONTH'];
			$rows['data'][$t] = $rows['data'][$t] + $rr['count(id)'];
		}

		/*
		while($rr1 = mysqli_fetch_array($sth1))
		{
		$t=$rr1['MONTH'];
		if(($rr1['count(id)']))
		$rows1['data'][$t] = $rows1['data'][$t] + $rr1['count(id)'];
		}*/
		
		while ($rr2 = mysqli_fetch_array($sth2))
		{
			$t = $rr2['MONTH'];
			$rows2['data'][$t] = $rows2['data'][$t] + $rr2['count(id)'];
		}

		while ($rr3 = mysqli_fetch_array($sth3))
		{
			$t = $rr3['MONTH'];
			$rows3['data'][$t] = $rows3['data'][$t] + $rr3['count(id)'];
		}
	}

	$t = 1;
	$p = sprintf('%02d', $t);
	while ($t <= 12)
	{
		$rowst['data'][] = $rows['data'][$p];
		//$rowst1['data'][] = $rows1['data'][$p];
		$rowst2['data'][] = $rows2['data'][$p];
		$rowst3['data'][] = $rows3['data'][$p];
		$t++;
		$p = sprintf('%02d', $t);
	}

	$t = 1;

	// echo '<script> console.log("'.$rows['data'][$t].'");</script>';

}

$result = array();
array_push($result, $rowst3);
array_push($result, $rowst2);
array_push($result, $rowst);
//array_push($result, $rowst1);
print json_encode($result, JSON_NUMERIC_CHECK);
mysqli_close($con);
?>
