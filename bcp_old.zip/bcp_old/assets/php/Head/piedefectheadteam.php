<?php
$con = mysqli_connect("127.0.0.1", "root", "", "bcp");

if (!$con)
{
	die('Could not connect: ' . mysqli_error());
}

// echo '<script>alert("'.$ids.'");</script>';

$empty = 1;

// echo '<script>console.log("'.$start_Date.'");</script>';

if (empty($_GET['ids'])) 
{
	$empty = 1;
}
else
{
	$empty = 0;
	$ids = $_GET['ids'];
}

$start_Date = $_GET['start_Date'];
$end_Date = $_GET['end_Date'];
$t = 1;

if ($empty == 1) 
{
	$sth = mysqli_query($con, "SELECT count(id) as t, category FROM incident where updation BETWEEN '$start_Date' AND '$end_Date' group by category");
}
else
{
	$all = array();

	//	echo '<script>console.log("'.$ids.'")</script>';

	$check = explode(",", $ids);
	$check = str_replace(' ', '', $check);

	// echo '<script>console.log("'.$check[1].'")</script>';

	foreach($check as $value)
	{

		// echo '<script>console.log("'.$value.'")</script>';

		$query = "SELECT UserId, ManagerId FROM steall where ManagerId='$value'";
		$data = mysqli_query($con, $query);

		// echo '<script>console.log("test1")</script>';
		// echo '<script>console.log("'.$value.'")</script>';

		if (mysqli_num_rows($data))
		{

			// echo '<script>console.log("test2")</script>';

			while ($row = mysqli_fetch_assoc($data))
			{

				// echo '<script>alert("'.$row['id'].'")</script>';

				$id = $row['UserId'];

				// echo '<script>console.log("'.$row['UserId'].'")</script>';

				$test[0] = $row['ManagerId'];
				$test[1] = $row['UserId'];
				array_push($all, $test);

				// echo '<script>console.log("'.$test[0].'= '.$test[1].'")</script>';

			}
		}
	}

	/*foreach ($all as $key => $value){
	echo '<script>console.log("'.$value[0].'= '.$value[1].'")</script>';
	}

	*/

	// $all = "'" . implode("','", $all) . "'";
	// echo '<script>console.log("'.$all.'")</script>';

	$ti = 0;
	$test = "SELECT SUM(t) as t,category FROM ( ";

	// //////////FIXED IT SOMEHOW/////////////////////////////////////////////////
	// $all=array('I332712','I332954','I325952');

	$llp = 0;
	foreach($all as $key => $tmp)
	{
		$user_start_date = 0;
		$user_end_date = 0;
		$tmpdate = mysqli_query($con, " SELECT DOJ as DOJ, LWD as LWD FROM steall where UserId = '$tmp[1]' and ManagerId = '$tmp[0]'  ");

		// $user_end_date=  mysqli_query($con ,  " SELECT LWD as LWD FROM steall where UserId = '$tmp[1]' and ManagerId = '$tmp[0]'  ") ;

		$tmpdate = mysqli_fetch_assoc($tmpdate);

		// $user_end_date=mysqli_fetch_assoc($user_end_date);

		$user_start_date = $tmpdate['DOJ'];
		$user_end_date = $tmpdate['LWD'];
		if ($ti == 0)
		{
			$ti = 1;
		}
		else $test.= " UNION ALL";
		$test.= " SELECT count(id) as t, category  FROM incident where userid= '$tmp[1]' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by category  ";
		$llp++;
		$ndJantoApril = mysqli_query($con, " SELECT count(id) as ndf FROM incident where userid='$tmp[1]' and (category='New defect')  and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '2010-01-01' AND '2018-03-31' and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2018-01-01' and '2018-12-31' ");

		// or category='Development Request'

		$totalJantoApril = mysqli_query($con, " SELECT count(id) as tdf FROM incident where userid='$tmp[1]' and (category!='Development Request') and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '2010-01-01' AND '2018-03-31' and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2018-01-01' and '2018-12-31' ");
		$data5 = mysqli_fetch_assoc($ndJantoApril);
		$data6 = mysqli_fetch_assoc($totalJantoApril);
		$ndJantoAprilF+= $data5['ndf'];
		$totalJantoAprilF+= $data6['tdf'];
	}

	$test.= " ) AS tbl where 1 = 1 group by category ";

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// $test = '"' .$test . '"';
	// echo '<script>console.log("'.$test.''.$llp.'")</script>';
	// echo '<script>console.log("tdjanapril= '.$totalJantoAprilF.'")</script>';
	// echo '<script>console.log("ndjanapril= '.$ndJantoAprilF.'")</script>';

	$sth = mysqli_query($con, $test);
	/*$sth = mysqli_query($con , " SELECT count(id),category FROM incident where exists
	(
	(SELECT count(id), category FROM incident where userid= 'I332712' and updation BETWEEN '2017-01-01' AND '2017-12-01' group by category)
	UNION ALL
	(SELECT count(id), category FROM incident where userid= 'I332954' and updation BETWEEN '2017-01-01' AND '2017-12-01' group by category)
	) group by category   ") ;
	*/
}

$rows1 = array();

// $rows1['name'] = 'New Defect';

$result = array();
$cat = array(
	"Consulting/User Handling",
	"Development Request",
	"Known Defect",
	"New Defect",
	"Not Reproducible Defect",
	"Other",
	"Test Case Description",
	"Test/Demo Customizing"
);
$ii = 0;
$rr = mysqli_fetch_array($sth);

while ($ii != 8)
{

	// if($rr['category']==$cat[$ii]){

	if (strcmp($rr['category'], $cat[$ii]) == 0 || ($rr['category'] == $cat[$ii]))
	{
		$row1[0] = $rr['category'];
		$row1[1] = $rr['t'];
		$rr = mysqli_fetch_array($sth);
	}
	else
	{
		$row1[0] = $cat[$ii];
		$row1[1] = 0;
	}

	// echo '<script>console.log("'.$row1[0].'='.$row1[1].'")</script>';

	array_push($result, $row1);
	$ii++;
}

$row1[0] = 'ndjtoa';
$row1[1] = $ndJantoAprilF;
array_push($result, $row1);
$row1[0] = 'tdjtoa';
$row1[1] = $totalJantoAprilF;
array_push($result, $row1);
print json_encode($result, JSON_NUMERIC_CHECK);
mysqli_close($con);
?>