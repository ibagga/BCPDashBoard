<?php

// This file copy of ProgramPieChart which is created to calculate the total defects for the Pie chart number 2. 
// Edit the Manager ids and date for the correct data
// http://localhost:8085/assets/php/Head/Total.php?ids=I061025,I031726,I035348,I057052,I029906,I027453,I054728,I076098,I044919,I032190&start_Date=2018-01-01&end_Date=2018-12-31

$con = mysqli_connect("127.0.0.1","root","","bcp");
//echo "<script type='text/javascript'>alert('1');</script>";
if (!$con) {
  die('Could not connect: ' . mysqli_error());
}
//mysqli_select_db("bcp", $con);

if(empty($_GET['ids']))
	//$ids = "I061025,I031726,I035348,I057052,I029906,I027453,I054728,I076098,I044919,I032190";
	$ids = "I029906";
else
	$ids = $_GET['ids'];

$start_Date = '2018-04-01';
$end_Date = '2018-12-31';

//$start_Date = $_GET['start_Date'];
//$end_Date = $_GET['end_Date'];
//echo "<script type='text/javascript'>alert('$start_Date');</script>";

$t=1;
		
		
			
		$all=array();
	
			//echo '<script>console.log("'.$ids.'")</script>';
			$check = explode(",", $ids);
			//echo "<script type='text/javascript'>alert('$check[0]');</script>";
			
			$check = str_replace(' ', '', $check);
			//echo '<script>console.log("'.$check[1].'")</script>';
		foreach ($check as $value){
				//echo "<script type='text/javascript'>alert('$value');</script>";
				
			//echo '<script>console.log("'.$value.'")</script>';
			$query = "SELECT UserId, ManagerId , DOJ as DOJ , LWD as LWD FROM steall where ManagerId='$value'";
			$data = mysqli_query($con , $query);
			//echo '<script>console.log("test1")</script>';
			//echo '<script>console.log("'.$value.'")</script>';
			if(mysqli_num_rows($data)){
				//echo '<script>console.log("test2")</script>';
			
				while($row = mysqli_fetch_assoc($data)){
				//echo '<script>alert("'.$row['id'].'")</script>';
				
					$id=$row['UserId'];
					
				//echo '<script>console.log("'.$row['UserId'].'")</script>';
					$test[0] = $row['ManagerId'];
					$test[1] = $row['UserId'];
					array_push($all,$test);
				//echo '<script>console.log("'.$row['ManagerId'].''.$row['UserId'].''.$row['DOJ'].''.$row['LWD'].'")</script>';
				}
						
		}
		
			
		}
			
			//harsh   2 s4h0p    3 soh
			//ishu    10 s4hop   1 soh
			//total        12 s4hop   4 soh
			$ti=0;
			$test="SELECT SUM(t) as t,program FROM ( ";
			
			////////////FIXED IT SOMEHOW/////////////////////////////////////////////////
			//$all=array('I332712','I332954','I325952');
			foreach($all as $key => $tmp)
			{
				
				$user_start_date=0;
				$user_end_date=0;
				$tmpdate=mysqli_query($con, " SELECT DOJ as DOJ, LWD as LWD FROM steall where UserId = '$tmp[1]' and ManagerId = '$tmp[0]'  ") ;
				//$user_end_date=  mysqli_query($con ,  " SELECT LWD as LWD FROM steall where UserId = '$tmp[1]' and ManagerId = '$tmp[0]'  ") ;
				$tmpdate=mysqli_fetch_assoc($tmpdate);
				//$user_end_date=mysqli_fetch_assoc($user_end_date);
				$user_start_date=$tmpdate['DOJ'];
				$user_end_date=$tmpdate['LWD'];
				
				if($ti==0){
					$ti=1;
				}
				else
					$test.=" UNION ALL";
				
				//Total Defect
				$test .=" SELECT count(DISTINCT id) as t, program  FROM incident left JOIN programmapping ON incident.System = programmapping.System where userid= '$tmp[1]' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by id";
				
				
				//Dev request
				//$test .=" SELECT count(DISTINCT id) as t, program  FROM incident left JOIN programmapping ON incident.System = programmapping.System where userid= '$tmp[1]' and category like '%dev%' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by id  ";
				
				
				/* $ndJantoApril = mysqli_query($con , " SELECT count(id) as ndf FROM incident where userid='$tmp[1]' and (category='New defect')  and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '2010-01-01' AND '2018-03-31' and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2018-04-01' and '2018-12-31' ") ;
				
				//or category='Development Request'
				$totalJantoApril = mysqli_query($con , " SELECT count(id) as tdf FROM incident where userid='$tmp[1]' and (category!='Development Request') and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '2010-01-01' AND '2018-03-31' and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2018-04-01' and '2018-12-31' ") ;
				
				$data5=mysqli_fetch_assoc($ndJantoApril);
				$data6=mysqli_fetch_assoc($totalJantoApril);
				$ndJantoAprilF+=$data5['ndf'];
				$totalJantoAprilF+=$data6['tdf']; */
				
				
				
			}
			$test.=" ) AS tbl where 1 = 1 group by program";
			
			////////////////////////////////////////////////////////////////////////////////////////////////
			//echo "<script type='text/javascript'>alert('Hi');</script>";

			//print $test;			
			//$sth = mysqli_query($con, $test);
			
			
			
				
				$row1 = array();
				$result = array();


				while( $rr = mysqli_fetch_array($sth)) 
				{
					
					   if($rr['program']=='')
						   $row1[0] = "NaN";
					   else
						$row1[0] = $rr['program'];
						//echo '<script>console.log("'.$row1[0].'")</script>';
						$row1[1] = $rr['t'];
						array_push($result,$row1);			
				}
				print json_encode($result, JSON_NUMERIC_CHECK);
			
			
			
			
			
			/*$sth = mysqli_query($con , " SELECT count(id),category FROM incident where exists 
			(
				(SELECT count(id), category FROM incident where userid= 'I332712' and updation BETWEEN '2017-01-01' AND '2017-12-01' group by category)
				UNION ALL
				(SELECT count(id), category FROM incident where userid= 'I332954' and updation BETWEEN '2017-01-01' AND '2017-12-01' group by category)
			) group by category   ") ;
			*/
			
			
		//echo "<script type='text/javascript'>alert('$ndJantoAprilF');</script>";
		//echo "<script type='text/javascript'>alert('$totalJantoAprilF');</script>";
		




mysqli_close($con);
//mysqli_close($con);
?>