<?php
$con = mysqli_connect("127.0.0.1","root","","bcp");

if (!$con) {
  die('Could not connect: ' . mysqli_error());
}

 
//echo '<script>alert("'.$ids.'");</script>';
$empty=1;

//echo '<script>console.log("'.$start_Date.'");</script>';
if(empty($_GET['ids']))
	$empty=1;
else{
	$empty=0;
	$ids = $_GET['ids'];
	//echo '<script>console.log("'.$ids.'");</script>';
}	
$start_Date = $_GET['start_Date'];
$end_Date = $_GET['end_Date'];
$t=1;
	if($empty==1)
		$sth = mysqli_query($con , "SELECT * FROM incident where 1=2 ");
	else{
		
		$all=array();

		//	echo '<script>console.log("'.$ids.'")</script>';
			$check = explode(",", $ids);
			$check = str_replace(' ', '', $check);
		
			$ti=0;
			$test="SELECT SUM(t) as t,program FROM ( ";
			
			////////////FIXED IT SOMEHOW/////////////////////////////////////////////////
			//$all=array('I332712','I332954','I325952');
			foreach($check as $tmp)
			{
				$tmp = str_replace("'", "", $tmp);
				$user_start_date=0;
				$user_end_date=0;
				$queryDate=mysqli_query($con ,  " SELECT min(DOJ) as DOJ , max(LWD) as LWD FROM steall where UserId = '$tmp'  ") ;
				//$user_end_date=  mysqli_query($con ,  " SELECT LWD as LWD FROM steall where UserId = '$tmp'  ") ;
				$queryDate=mysqli_fetch_assoc($queryDate);
				//$user_end_date=mysqli_fetch_assoc($user_end_date);
				$user_start_date=$queryDate['DOJ'];
				$user_end_date=$queryDate['LWD'];
				
				if($ti==0){
					$ti=1;
				}
				else
					$test.=" UNION ALL";
				// maintain comment
				$test .=" SELECT count(DISTINCT id) as t, program  FROM incident left JOIN programmapping ON incident.System = programmapping.System where category='New Defect'and userid= '$tmp' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by Program  ";
				
			}
			$test.=" ) AS tbl where 1 = 1 group by program ";
			////////////////////////////////////////////////////////////////////////////////////////////////
			//$test = '"' .$test . '"';
			
			//echo '<script>console.log("'.$test.'")</script>';
			$sth = mysqli_query($con , $test);
			/*$sth = mysqli_query($con , " SELECT count(id),category FROM incident where exists 
			(
				(SELECT count(id), category FROM incident where userid= 'I332712' and updation BETWEEN '2017-01-01' AND '2017-12-01' group by category)
				UNION ALL
				(SELECT count(id), category FROM incident where userid= 'I332954' and updation BETWEEN '2017-01-01' AND '2017-12-01' group by category)
			) group by category   ") ;
			*/
	}		
		
$rows1 = array();

//$rows1['name'] = 'New Defect';
$result = array();
while( $rr = mysqli_fetch_array($sth)) {
	
	   
		if($rr['program']=='')
		   $row1[0] = "NaN";
	   else
		$row1[0] = $rr['program'];
		//echo '<script>console.log("'.$row1[1].'")</script>';
		$row1[1] = $rr['t'];
		array_push($result,$row1);
		

		
}

	

print json_encode($result, JSON_NUMERIC_CHECK);


mysqli_close($con);
?>
