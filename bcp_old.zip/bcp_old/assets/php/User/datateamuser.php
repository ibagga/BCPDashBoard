<?php
$con = mysqli_connect("127.0.0.1","root","","bcp");

if (!$con) {
  die('Could not connect: ' . mysqli_error());
}

 
$empty=1;

if(empty($_GET['ids']))
	$empty=1;
else{
	$empty=0;
	$ids = $_GET['ids'];
}
$start_Date = $_GET['start_Date'];
$end_Date = $_GET['end_Date'];
$mon= str_split($start_Date,4);	// 2018-10-31
//echo '<script>console.log("'.$ids.'");</script>';
//$ids    = json_decode("$ids", true);
//echo '<script>alert("'.$ids.'");</script>';
$t=1;
	if($empty==1)
		$sth = mysqli_query($con , "SELECT count(id) where 1=0 ");
	else
		$sth = mysqli_query($con , "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'New Defect' and SUBSTRING(updation, 1, 4) = '$mon[0]' and  userid IN ($ids) group by SUBSTRING(updation, 6, 2) ");
$rows1 = array();
$rows1['name'] = 'New Defect';
while( $t<=12) {
	$rr = mysqli_fetch_array($sth);
	$f=$rr['MONTH'];
	 $p = sprintf('%02d', $t);
	 //echo '<script> console.log("'.$p.'");</script>';
	while( strcasecmp( $p, $f )!= 0 && $t<=12)
	{
		
		
		$rows1['data'][]=0;
		$t++;
		$p = sprintf('%02d', $t);
		//echo '<script> console.log("'.$p.'");</script>';
	}
	if($t<=12){
		$rows1['data'][] = $rr['count(id)'];
		$t++;
	}
		
}
$t=1;
	if($empty==1)
		$sth = mysqli_query($con , "SELECT count(id) where 1=0 ");
	else
		$sth = mysqli_query($con , "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where category= 'Development Request' and SUBSTRING(updation, 1, 4) = '$mon[0]' and userid IN ($ids) group by SUBSTRING(updation, 6, 2) ");
$rows2 = array();
$rows2['name'] = 'Development Request';
while( $t<=12) {
	$rr = mysqli_fetch_array($sth);
	$f=$rr['MONTH'];
	 $p = sprintf('%02d', $t);
	 //echo '<script> console.log("'.$p.'");</script>';
	while( strcasecmp( $p, $f )!= 0 && $t<=12)
	{
		
		
		$rows2['data'][]=0;
		$t++;
		$p = sprintf('%02d', $t);
		//echo '<script> console.log("'.$p.'");</script>';
	}
	if($t<=12){
		$rows2['data'][] = $rr['count(id)'];
		$t++;
	}
		
}
$t=1;
	if($empty==1)
		$sth = mysqli_query($con , "SELECT count(id) where 1=0 ");
	else
		$sth = mysqli_query($con , "SELECT count(id), SUBSTRING(updation, 6, 2) as MONTH FROM incident where SUBSTRING(updation, 1, 4) = '$mon[0]' and userid IN ($ids) group by SUBSTRING(updation, 6, 2) ");
$rows3 = array();
$rows3['name'] = 'Incident confirmed';
while( $t<=12) {
	$rr = mysqli_fetch_array($sth);
	$f=$rr['MONTH'];
	 $p = sprintf('%02d', $t);
	 //echo '<script> console.log("'.$p.'");</script>';
	while( strcasecmp( $p, $f )!= 0 && $t<=12)
	{
		
		
		$rows3['data'][]=0;
		$t++;
		$p = sprintf('%02d', $t);
		//echo '<script> console.log("'.$p.'");</script>';
	}
	if($t<=12){
		$rows3['data'][] = $rr['count(id)'];
		$t++;
	}
		
}	
	
$t=1;
	if($empty==1)
		$sth = mysqli_query($con , "SELECT count(id) where 1=0 ");
	else
		$sth = mysqli_query($con , "SELECT count(id), SUBSTRING(creation, 6, 2) as MONTH FROM incident where SUBSTRING(creation, 1, 4) = '$mon[0]' and userid IN ($ids) group by SUBSTRING(creation, 6, 2) ");

$rows = array();
$rows['name'] = 'Incident created';
while( $t<=12) {
	$rr = mysqli_fetch_array($sth);
	$f=$rr['MONTH'];
	 $p = sprintf('%02d', $t);
	 //echo '<script> console.log("'.$p.'");</script>';
	while( strcasecmp( $p, $f )!= 0 && $t<=12)
	{
		
		
		$rows['data'][]=0;
		$t++;
		$p = sprintf('%02d', $t);
		//echo '<script> console.log("'.$p.'");</script>';
	}
	if($t<=12){
		$rows['data'][] = $rr['count(id)'];
		$t++;
	}
		
}


$result = array();

array_push($result,$rows);
array_push($result,$rows3);
array_push($result,$rows1);
array_push($result,$rows2);



print json_encode($result, JSON_NUMERIC_CHECK);

mysqli_close($con);
?>
