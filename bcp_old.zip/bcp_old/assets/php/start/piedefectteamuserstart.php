<?php
$con = mysqli_connect("127.0.0.1","root","","bcp");

if (!$con) {
  die('Could not connect: ' . mysqli_error());
}

 
//echo '<script>alert("'.$ids.'");</script>';

$empty=1;

if(empty($_GET['ids']))
	$empty=1;
else{
	$empty=0;
	$ids = $_GET['ids'];
	//$ids    = json_decode("$ids", true);
	$ids = explode(",", $ids);
	$ids = str_replace(' ', '', $ids);
	//echo '<script>console.log("'.$ids.'")</script>';
	}	
$start_Date = $_GET['start_Date'];
$end_Date = $_GET['end_Date'];
$t=1;
	if($empty==1)
		$sth = mysqli_query($con , "SELECT count(id), category FROM startIncident where 1=0");
	else{
		//$sth = mysqli_query($con , "SELECT count(id), category FROM incident where (status='Confirmed' or status='Completed for Author') and userid IN ($ids) group by category ");
		$ti=0;
			$test="SELECT SUM(t) as t,category FROM ( ";
			
			////////////FIXED IT SOMEHOW/////////////////////////////////////////////////
			//$all=array('I332712','I332954','I325952');
			foreach($ids as $tmp)
			{
				$tmp = str_replace("'", "", $tmp);
				//echo '<script>console.log("'.$tmp.'")</script>';
				$user_start_date=0;
				$user_end_date=0;
				$user_start_date=mysqli_query($con ,  " SELECT DOJ as DOJ FROM steall where UserId = '$tmp'   ") ;
				$user_end_date=  mysqli_query($con ,  " SELECT LWD as LWD FROM steall where UserId = '$tmp'   ") ;
				$user_start_date=mysqli_fetch_assoc($user_start_date);
				$user_end_date=mysqli_fetch_assoc($user_end_date);
				$user_start_date=$user_start_date['DOJ'];
				$user_end_date=$user_end_date['LWD'];
				
				if($ti==0){
					$ti=1;
				}
				else
					$test.=" UNION ALL";
				
				$test .=" SELECT count(id) as t, category  FROM startIncident where userid= '$tmp' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date' group by category  ";
				
			}
			$test.=" ) AS tbl where 1 = 1 group by category ";
			////////////////////////////////////////////////////////////////////////////////////////////////
			//$test = '"' .$test . '"';
			
			//echo '<script>console.log("'.$test.'")</script>';
			$sth = mysqli_query($con , $test);	
	}
		
$rows1 = array();

//$rows1['name'] = 'New Defect';
$result = array();
while( $rr = mysqli_fetch_array($sth)) {
	
	   if($rr['category']=="New Defect")
		$row1[0] = "Code Fixes";
	   else if($rr['category']=="Not Reproducible Defect")
		$row1[0] = "Not Reproducible";
	   else
		$row1[0] = $rr['category'];
		$row1[1] = $rr['t'];
		array_push($result,$row1);
		

		
}

	

/*
$sth = mysqli_query($con , "SELECT SUBSTRING(updation, 4, 2) as MONTH FROM incident  group by SUBSTRING(updation, 4, 2)");
$rows = array();
$rows['name'] = 'Month';
while($r = mysqli_fetch_array($sth)) {
    $rows['data'][] = $r['MONTH'];
}
*/



//$result=str_replace('name','\'"',$result);
//$result=str_replace('"]]','"\']',$result);
print json_encode($result, JSON_NUMERIC_CHECK);


mysqli_close($con);
?>
