<?php

echo $_SERVER['LOGON_USER'];

?>