	<?php

	//include 'dp.php';
	$con= mysqli_connect("127.0.0.1","root","","bcp");

	if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	$value = $_POST['data'];
	$start_Date = $_POST['start_Date'];
	$end_Date = $_POST['end_Date'];

	//		echo sizeof($data);
	$test = [];
	$totalcount=0;
	$totalnewdefect=0;
	$totalhighdefect=0;
	$devreqdefect=0;
	$knowndefect=0;
	$notreproducibledefect=0;
	$consultingdefect=0;
	$testdemodefect=0;
	$testcasedefect=0;
	$otherdefect=0;
	$i=0;

	$user_start_date=0;
			$user_end_date=0;
			$user_start_date=mysqli_query($con,  " SELECT min(DOJ) as DOJ FROM steall where UserId = '$value'   ") ;
			$user_end_date=  mysqli_query($con,  " SELECT max(LWD) as LWD FROM steall where UserId = '$value'   ") ;
			$user_start_date=mysqli_fetch_assoc($user_start_date);
			$user_end_date=mysqli_fetch_assoc($user_end_date);
			$user_start_date=$user_start_date['DOJ'];
			$user_end_date=$user_end_date['LWD'];

		$test[$i++] = $value;
		$totalincidents = mysqli_query($con, " SELECT count(id) as total FROM incident where userid='$value' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date'   ") ;
		$newdefect =  mysqli_query($con, " SELECT count(category) as newdefect FROM incident where userid='$value'  and category='New defect' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;
		$highdefect =  mysqli_query($con, " SELECT count(priority) as highdefect FROM incident where userid='$value' and category='New defect' and  (priority='High' || priority='Very High') and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date'   ") ;			
		$devreq = mysqli_query($con, " SELECT count(id) as devreq FROM incident where userid='$value' and category='Development request' and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '$user_start_date' AND '$user_end_date'   ") ;			
		//$knowndefect = mysqli_query($con, " SELECT count(id) as knowndefect FROM incident where userid='$value' and category='Known defect' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
		//$notreproducible = mysqli_query($con, " SELECT count(id) as notreproducible FROM incident where userid='$value' and category='Not reproducible' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
		//$consulting = mysqli_query($con, " SELECT count(id) as consulting FROM incident where userid='$value' and category='Consulting/User handling' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
		//$testdemo = mysqli_query($con, " SELECT count(id) as testdemo FROM incident where userid='$value' and category='Test/Demo customizing' and and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
		//$testcase = mysqli_query($con, " SELECT count(id) as testcase FROM incident where userid='$value' and category='Test case description' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
		//$other = mysqli_query($con, " SELECT count(id) as other FROM incident where userid='$value' and category='Other' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
		
		$data1=mysqli_fetch_assoc($totalincidents);
		$data2=mysqli_fetch_assoc($newdefect);
		$data3=mysqli_fetch_assoc($highdefect);
		$data4=mysqli_fetch_assoc($devreq);
		//$data5=mysqli_fetch_assoc($knowndefect);
		//$data6=mysqli_fetch_assoc($notreproducible);
		//$data7=mysqli_fetch_assoc($consulting);
		//$data8=mysqli_fetch_assoc($testdemo);
		//$data9=mysqli_fetch_assoc($testcase);
		//$data10=mysqli_fetch_assoc($other);
		
		$totalcount+=$data1['total'];
		$totalnewdefect+=$data2['newdefect'];
		$totalhighdefect+=$data3['highdefect'];
		$devreqdefect+=$data4['devreq'];
		//$knowndefect+=$data5['knowndefect'];
		//$notreproducibledefect+=$data6['notreproducible'];
		//$consultingdefect+=$data7['consulting'];
		//$testdemodefect+=$data8['testdemo'];
		//$testcasedefect+=$data9['testcase'];
		//$otherdefect+=$data10['other'];
		$ndJantoApril = mysqli_query($con, " SELECT count(id) as ndf FROM incident where userid='$value' and (category='New defect')  and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '2010-01-01' AND '2018-03-31' and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2018-01-01' and '2018-12-31' ") ;
			//or category='Development Request'
		$totalJantoApril = mysqli_query($con, " SELECT count(id) as tdf FROM incident where userid='$value' and (category!='Development Request') and updation BETWEEN '$start_Date' AND '$end_Date' and creation BETWEEN '2010-01-01' AND '2018-03-31' and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2018-01-01' and '2018-12-31'  ") ;
			
		$data5=mysqli_fetch_assoc($ndJantoApril);
		$data6=mysqli_fetch_assoc($totalJantoApril);
		$ndJantoAprilF+=$data5['ndf'];
		$totalJantoAprilF+=$data6['tdf'];
		

	$load = array($totalcount, $totalnewdefect, $totalhighdefect, $devreqdefect, $knowndefect, $notreproducibledefect, $consultingdefect, $testdemodefect, $testcasedefect, $otherdefect,$ndJantoAprilF,$totalJantoAprilF );



	echo json_encode($load);
	//echo $totalcount;
	//echo '<script>alert("'.$data.'")</script>';
	/*
	$query = "SELECT * FROM user";
	$data = mysqli_query($con,$query);
	if(mysqli_num_rows($data)){
		
		
		while($row = mysqli_fetch_assoc($data)){
			$id=$row['id'];
			echo '<option value="'.$id.'">' . $id . '</option>';  
		}	
	}	
	  
	*/
mysqli_close($con);

	?>