<?php 
$con= mysqli_connect("127.0.0.1","root","","bcp");

        if (mysqli_connect_errno()){
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
	$id = $_POST['id'];
	$query = "SELECT * FROM steall where ManagerId='$id' limit 1 ";
	//$query= "SELECT mapped FROM superuser WHERE id ='I332712' ";
	$data = mysqli_query($con,$query);
	while($row = mysqli_fetch_assoc($data)){
		$role=$row['ManagerId'];
	}
	//echo '<script>alert("'.$role.'");</script>';
	$query2 = "SELECT ManagerId FROM steall where UserId='$id' limit 1 ";
	//$query= "SELECT mapped FROM superuser WHERE id ='I332712' ";
	$data2 = mysqli_query($con,$query2);
	while($row2 = mysqli_fetch_assoc($data2)){
		$role2=$row2['ManagerId'];
	}
	//ec
	if ( $id=='I027453' ||$role2=='i027453')
		echo 'startuser';
	else if($role=='')
		echo 'user';
	else
		echo $role;
	mysqli_close($con);
	

?>