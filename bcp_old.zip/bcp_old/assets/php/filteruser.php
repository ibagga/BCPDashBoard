<?php
//$domainUser=$_SERVER['PHP_AUTH_USER'];
//echo '<script>alert('.$domainUser.');</script>';
 

$value = $_POST['data'];
//echo '<script>alert('.$value.');</script>';
//echo "Username: " . $_SERVER["PHP_AUTH_USER"] 
		include 'dp.php';
		$con= mysqli_connect("127.0.0.1","root","","bcp");

        if (mysqli_connect_errno()){
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        $query = "SELECT * FROM steall where ManagerId='$value' order by name" ;
		$data = mysqli_query($con,$query);
        if(mysqli_num_rows($data)){
			
			
			while($row = mysqli_fetch_assoc($data)){
				$id=$row['UserId'];
				$name=$row['Name'];
				echo '<option value="'.$id.'">' . $name . '</option>';  
			}	
		}	
          
        mysqli_close($con);
      
		
?>