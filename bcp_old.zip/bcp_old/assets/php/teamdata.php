<?php

		//include 'dp.php';
		$con = mysqli_connect("127.0.0.1","root","","bcp");

		if (!$con) {
		  die('Could not connect: ' . mysqli_error());
		}
		 
		$data = $_POST['data'];
		$start_Date = $_POST['start_Date'];
		$end_Date = $_POST['end_Date'];
		//$start_Date = '2017-01-01';
		//$end_Date = '2017-12-01';
		$count=0;
		$checkcount;
		
		//echo '<script>console.log("'.$start_Date.'")</script>';
		

//		echo sizeof($data);
		$test = [];
		$totalcount=0;
		$totalnewdefect=0;
		$totalhighdefect=0;
		$devreqdefect=0;
		/*$knowndefect=0;
		$notreproducibledefect=0;
		$consultingdefect=0;
		$testdemodefect=0;
		$testcasedefect=0;
		$otherdefect=0;
		*/
		$i=0;
		if($_POST['data']=="novalue" || $_POST['data']=="[]"|| $_POST['data']=="[0]"){
			$count=0;
			//$totalincidents = mysqli_query($con ,  " SELECT count(id) as total FROM incident where updation BETWEEN '$start_Date' AND '$end_Date'  ") ;
			//$newdefect =  mysqli_query($con ,  " SELECT count(category) as newdefect FROM incident where category='New defect' and updation BETWEEN '$start_Date' AND '$end_Date' ") ;
			//$highdefect =  mysqli_query($con ,  " SELECT count(priority) as highdefect FROM incident where category='New defect' and priority='High' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			//$devreq = mysqli_query($con ,  " SELECT count(id) as devreq FROM incident where category='Development request' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			/*$knowndefect = mysqli_query($con, " SELECT count(id) as knowndefect FROM incident where category='Known defect' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			$notreproducible = mysqli_query($con, " SELECT count(id) as notreproducible FROM incident where category='Not reproducible' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			$consulting = mysqli_query($con, " SELECT count(id) as consulting FROM incident where category='Consulting/User handling' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			$testdemo = mysqli_query($con, " SELECT count(id) as testdemo FROM incident where category='Test/Demo customizing' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			$testcase = mysqli_query($con, " SELECT count(id) as testcase FROM incident where category='Test case description' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			$other = mysqli_query($con, " SELECT count(id) as other FROM incident where category='Other' and updation BETWEEN '$start_Date' AND '$end_Date'  ") ;			
			*/
			
			
			
		//echo '<script>console.log("'.$start_Date.'");</script>';
		$userstart_Date = date('Y-m-15', strtotime('+0 month', strtotime($start_Date)));
		//echo '<script>console.log("'.$date.'");</script>';
		
		//$dy = date('Y-m', strtotime('+1 month', strtotime($start_Date)));
		//echo '<script>console.log("'.$dy.'");</script>';
		//if('2017-12'==  date('Y-m', strtotime('+0 month', strtotime($end_Date))))
		//	echo '<script>console.log("great");</script>';
		$i=0;
		
		while(1)
		{
			//echo '<script>console.log("'.$userstart_Date.'= '.$end_Date.'");</script>';
			
			
			
			$query2 = "SELECT count(UserId) as f FROM steall where ManagerId!='I027453' and '$userstart_Date' between SUBSTRING(DOJ, 1, 10) and SUBSTRING(LWD, 1, 10) and Auto_EXE!='E' ";
			$data2 = mysqli_query($con , $query2);
			//echo '<script>console.log("test1")</script>';
			//echo '<script>console.log("'.$value.'")</script>';
			if(mysqli_num_rows($data2)){
				while($row2 = mysqli_fetch_assoc($data2)){
				
					$count+=$row2['f'];
					$i++;
				//	echo '<script>console.log("'.$count.'")</script>';
				}
			//	echo '<script>console.log("'.$count.'")</script>';
			}
			//echo '<script>console.log("'.$count.'")</script>';
			
			if($userstart_Date == date('Y-m-15', strtotime('+0 month', strtotime($end_Date))))
				//$count=$count-$row2['f'];
				
				break;
			$userstart_Date = date('Y-m-15', strtotime('+1 month', strtotime($userstart_Date)));
			
			//$i++;
			//echo '<script>a("'.$i.'");</script>';
			//echo '<script>console.log("'.$userstart_Date.'= '.$end_Date.'");</script>';
		}
		$count=$count/$i;
		//echo '<script>console.log("'.$count.'");</script>';

			
			//$data1=mysqli_fetch_assoc($totalincidents);
			//$data2=mysqli_fetch_assoc($newdefect);
			//$data3=mysqli_fetch_assoc($highdefect);
			//$data4=mysqli_fetch_assoc($devreq);
			/*$data5=mysqli_fetch_assoc($knowndefect);
			$data6=mysqli_fetch_assoc($notreproducible);
			$data7=mysqli_fetch_assoc($consulting);
			$data8=mysqli_fetch_assoc($testdemo);
			$data9=mysqli_fetch_assoc($testcase);
			$data10=mysqli_fetch_assoc($other);
			*/
			//$totalcount+=$data1['total'];
			//$totalnewdefect+=$data2['newdefect'];
			//$totalhighdefect+=$data3['highdefect'];
			//$devreqdefect+=$data4['devreq'];
			/*knowndefect+=$data5['knowndefect'];
			$notreproducibledefect+=$data6['notreproducible'];
			$consultingdefect+=$data7['consulting'];
			$testdemodefect+=$data8['testdemo'];
			$testcasedefect+=$data9['testcase'];
			$otherdefect+=$data10['other'];	
			*/
		}
		else{
			$count=0;
			$data    = json_decode("$data", true);
		
			
			
		foreach ($data as $value){
			

			
		//echo '<script>console.log("'.$start_Date.'");</script>';
		$userstart_Date = date('Y-m-15', strtotime('+0 month', strtotime($start_Date)));
		//echo '<script>console.log("'.$userstart_Date.'");</script>';
		
		//$dy = date('Y-m', strtotime('+1 month', strtotime($start_Date)));
		//echo '<script>console.log("'.$dy.'");</script>';
		//if('2017-12'==  date('Y-m', strtotime('+0 month', strtotime($end_Date))))
		//	echo '<script>console.log("great");</script>';
		
		$i=0;
		while(1)
		{
			//echo '<script>console.log("'.$userstart_Date.'= '.$end_Date.'");</script>';
			
			
			
			$query2 = "SELECT count(UserId) as f FROM steall where ManagerId='$value' and ManagerId!='I027453' and'$userstart_Date' between SUBSTRING(DOJ, 1, 10) and SUBSTRING(LWD, 1, 10) and Auto_EXE!='E' ";
			//echo '<script>console.log("'.$query2.'")</script>';
			$data2 = mysqli_query($con , $query2);
			//echo '<script>console.log("test1")</script>';
			//echo '<script>console.log("'.$value.'")</script>';
			if(mysqli_num_rows($data2)){
				while($row2 = mysqli_fetch_assoc($data2)){
				
					$count+=$row2['f'];
					$i++;
				//	echo '<script>console.log("'.$count.'")</script>';
				}
				//echo '<script>console.log("'.$count.'")</script>';
			}
			//echo '<script>console.log("'.$count.'")</script>';
			
			if($userstart_Date == date('Y-m-15', strtotime('+0 month', strtotime($end_Date)))){
				//$count=$count-$row2['f'];
				//$i--;
				break;
			}
			$userstart_Date = date('Y-m-15', strtotime('+1 month', strtotime($userstart_Date)));
			//$i++;
			//echo '<script>a("'.$i.'");</script>';
			//echo '<script>console.log("'.$userstart_Date.'= '.$end_Date.'");</script>';
		}

			
			
			//$query = "SELECT UserId,DOJ as DOJ,LWD as LWD  FROM steall where ManagerId='$value'";
			//$data = mysqli_query($con , $query);
			//if(mysqli_num_rows($data)){
			
			
			//while($row = mysqli_fetch_assoc($data)){
				//echo '<script>alert("'.$row['id'].'")</script>';
			

			//$checkcount++;
			//$id=$row['UserId'];
			//$user_start_date=mysqli_query($con, " SELECT DOJ as DOJ FROM steall where UserId = '$id' and ManagerId='$value'  ") ;
			//$user_end_date=  mysqli_query($con, " SELECT LWD as LWD FROM steall where UserId = '$id' and ManagerId='$value'  ") ;
			//$user_start_date=mysqli_fetch_assoc($user_start_date);
			//$user_end_date=mysqli_fetch_assoc($user_end_date);
			//$user_start_date=$row['DOJ'];
			//$user_end_date=$row['LWD'];	
			
			//$totalincidents = mysqli_query($con , " SELECT count(id) as total FROM incident where userid='$id' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;
			//$newdefect =  mysqli_query($con ,  " SELECT count(category) as newdefect FROM incident where userid='$id'  and category='New defect' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date' ") ;
			//$highdefect =  mysqli_query($con , " SELECT count(priority) as highdefect FROM incident where userid='$id' and category='New defect' and priority='High' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			//$devreq = mysqli_query($con , " SELECT count(id) as devreq FROM incident where userid='$id' and category='Development request' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			/*$knowndefect = mysqli_query($con, " SELECT count(id) as knowndefect FROM incident where userid='$id' and category='Known defect' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			$notreproducible = mysqli_query($con, " SELECT count(id) as notreproducible FROM incident where userid='$id' and category='Not reproducible' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			$consulting = mysqli_query($con, " SELECT count(id) as consulting FROM incident where userid='$id' and category='Consulting/User handling' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			$testdemo = mysqli_query($con, " SELECT count(id) as testdemo FROM incident where userid='$id' and category='Test/Demo customizing' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			$testcase = mysqli_query($con, " SELECT count(id) as testcase FROM incident where userid='$id' and category='Test case description' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			$other = mysqli_query($con, " SELECT count(id) as other FROM incident where userid='$id' and category='Other' and updation BETWEEN '$start_Date' AND '$end_Date' and updation BETWEEN '$user_start_date' AND '$user_end_date'  ") ;			
			*/
			//$data1=mysqli_fetch_assoc($totalincidents);
			//$data2=mysqli_fetch_assoc($newdefect);
			//$data3=mysqli_fetch_assoc($highdefect);
			//$data4=mysqli_fetch_assoc($devreq);
			/*$data5=mysqli_fetch_assoc($knowndefect);
			$data6=mysqli_fetch_assoc($notreproducible);
			$data7=mysqli_fetch_assoc($consulting);
			$data8=mysqli_fetch_assoc($testdemo);
			$data9=mysqli_fetch_assoc($testcase);
			$data10=mysqli_fetch_assoc($other);
			*/
			//$totalcount+=$data1['total'];
			//$totalnewdefect+=$data2['newdefect'];
			//$totalhighdefect+=$data3['highdefect'];
			//$devreqdefect+=$data4['devreq'];
			/*$knowndefect+=$data5['knowndefect'];
			$notreproducibledefect+=$data6['notreproducible'];
			$consultingdefect+=$data7['consulting'];
			$testdemodefect+=$data8['testdemo'];
			$testcasedefect+=$data9['testcase'];
			$otherdefect+=$data10['other'];
			*/
				
				//$name=$row['name'];
				//echo '<option value="'.$id.'">' . $name . '</option>';  
			//}
						
		//}
		
			
		}
		$count=$count/$i;
		}	
		//$load = array($totalcount, $totalnewdefect, $totalhighdefect, $devreqdefect, $knowndefect, $notreproducibledefect, $consultingdefect, $testdemodefect, $testcasedefect, $otherdefect,$count );
		$load = array($totalcount, $totalnewdefect, $totalhighdefect, $devreqdefect, 0, 0, 0, 0, 0, 0,$count );
		
		
				echo json_encode($load);
		
		
      mysqli_close($con);
		
?>