<?php
$con = mysqli_connect("127.0.0.1","root","","bcp");

if (!$con) {
  die('Could not connect: ' . mysqli_error());
}

 
//echo '<script>alert("'.$ids.'");</script>';
		$sth = mysqli_query($con , "SELECT count(id), category FROM incident where (status='Confirmed' or status='Completed for Author') and category <> 'New defect' group by category ");
$rows1 = array();

//$rows1['name'] = 'New Defect';
while( $rr = mysqli_fetch_array($sth)) {
	
	    //$rows1['data']['name'][] = $rr['category'];
		//$rows1['data']['y'][] = $rr['count(id)'];
		
		
		$data4[] = array('name' => $rr['category'], 'y' => $rr['count(id)']);
		

		
}

	

/*
$sth = mysqli_query($con , "SELECT SUBSTRING(updation, 4, 2) as MONTH FROM incident  group by SUBSTRING(updation, 4, 2)");
$rows = array();
$rows['name'] = 'Month';
while($r = mysqli_fetch_array($sth)) {
    $rows['data'][] = $r['MONTH'];
}
*/

$result = array();

//array_push($result,$rows);
//array_push($result,$rows3);
array_push($result,$data4);
//array_push($result,$rows2);


$result=str_replace('name','\'"',$result);
//$result=str_replace('"]]','"\']',$result);
print json_encode($result, JSON_NUMERIC_CHECK);


mysqli_close($con);
?>
