<?php
$con = mysqli_connect("127.0.0.1","root","","bcp");

if (!$con) {
  die('Could not connect: ' . mysqli_error());
}

 
//echo '<script>alert("'.$ids.'");</script>';

$empty=1;
header("Content-Disposition: attachment; filename=\"demo.xls\"");
header("Content-Type: application/vnd.ms-excel;");
header("Expires: 0");
$out = fopen("php://output", 'w');

if(empty($_GET['ids']))
	$empty=1;
else{
	$empty=0;
	$loggeduser = 'I029906';
	$ids = $_GET['ids'];
	//$ids    = json_decode("$ids", true);
	$ids = explode(",", $ids);
	$ids = str_replace(' ', '', $ids);
	//echo '<script>console.log("'.$ids.'")</script>';
	}	
$t=1;

		$ti=0;

			$llp=0;
			foreach($ids as $tmp)
			{
				$tmp = str_replace("'", "", $tmp);
				//echo '<script>console.log("'.$tmp.'")</script>';
				$user_start_date=0;
				$user_end_date=0;
				$user_start_date=mysqli_query($con ,  " SELECT DOJ as DOJ FROM steall where UserId = '$tmp' and managerId='I029906'   ") ;
				$user_end_date=  mysqli_query($con ,  " SELECT LWD as LWD FROM steall where UserId = '$tmp' and managerId='I029906'   ") ;
				$user_start_date=mysqli_fetch_assoc($user_start_date);
				$user_end_date=mysqli_fetch_assoc($user_end_date);
				$user_start_date=$user_start_date['DOJ'];
				$user_end_date=$user_end_date['LWD'];
				
				$llp++;

				$database = mysqli_query($con , " SELECT * FROM incident where userid='$tmp'  and creation BETWEEN '$user_start_date' AND '$user_end_date' and updation between '2019-01-01' and '2019-09-30' and creation between '2019-01-01' and '2019-09-30'") ;
				if ($database)
				  {
				  // Fetch one and one row
				  while ($row=mysqli_fetch_row($database))
					{
					fputcsv($out, $row,"\t");
					}
				  mysqli_free_result($database);
				}
				//$database1=mysqli_fetch_assoc($database);
				//array_push($fdata,$database1);
				//echo($database1);
				//fwrite($myfile, $database1);
				//fwrite($out, $database1); 
				
				//var_dump($database1);
				   //$rows[] = $database1;



			}
	
	
	//print json_encode($rows);

mysqli_close($con);
	fclose($out);
?>
