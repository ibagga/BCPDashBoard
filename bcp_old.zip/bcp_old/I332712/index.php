
<?php 
$user=getenv("username");
echo '<script>alert("'.$user.'");</script>';
if($user=='I332712'){
	echo '<script>window.location.replace("http://localhost:8080/bcp/examples/dashboard.html");</script>';
}

 ?>
